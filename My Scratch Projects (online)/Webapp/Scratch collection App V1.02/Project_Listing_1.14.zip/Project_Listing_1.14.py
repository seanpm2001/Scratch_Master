print ("My scratch projects")
print ("from scratch.mit.edu")
print ("\n1336 items")
print ("0001 | seans epic trivia 5 trivia type challenge       |")
print ("0002 | The maze                                        |")
print ("0003 | Sean and mitchells puppy paradise movie         |")
print ("0004 | Meme's first scratch                            |")
print ("0005 | immortal combat dragon version                  |")
print ("0006 | Halloween                                       |")
print ("0007 | Super Scratch Pong 2                            |")
print ("0008 | Defend the planet                               |")
print ("0009 | Archer I                                        |")
print ("0010 | TRM Quiz                                        |")
print ("0011 | Castle Siege Scratch                            |")
print ("0012 | Grand Theft Auto - scratch                      |")
print ("0013 | The lab \"rat\"                                   |")
print ("0014 | White house down                                |")
print ("0015 | Crossy scratch                                  |")
print ("0016 | I like trains scratch edition                   |")
print ("0017 | Five nights at scratch                          |")
print ("0018 | NASA scratch                                    |")
print ("0019 | Multiplication tables with scratch cat          |")
print ("0020 | Bounce Party!!!!!!!!!!!!!!!!!!!!!!!!!!!         |")
print ("0021 | Gold rush                                       |")
print ("0022 | Turkey Nightmare IV                             |")
print ("0023 | Turkey simulator                                |")
print ("0024 | Dodge The Bullet -Turkey edition                |")
print ("0025 | Don't shoot the turkey                          |")
print ("0026 | Turkey stuffing                                 |")
print ("0027 | Si high demo                                    |")
print ("0028 | Dumb ways to scratch                            |")
print ("0029 | Girl Game I                                     |")
print ("0030 | Escape the prison - scratch                     |")
print ("0031 | War survival                                    |")
print ("0032 | Rayco.com                                       |")
print ("0033 | Super scratch pong 2015                         |")
print ("0034 | Ancient warfare I                               |")
print ("0035 | Job career test                                 |")
print ("0036 | Unlucky buttons                                 |")
more1 = input("View 50 more [ENTER]")
print ("0037 | Nuclear cat roadmine                            |")
print ("0038 | Uncle Unicapricornicopria                       |")
print ("0039 | Neon scratch                                    |")
print ("0040 | Lol cat                                         |")
print ("0041 | Nauseator                                       |")
print ("0042 | Instruments                                     |")
print ("0043 | The sounds of scratch                           |")
print ("0044 | None direction band                             |")
print ("0045 | Die hard                                        |")
print ("0046 | Bomb simulator                                  |")
print ("0047 | Are you like Sean quiz                          |")
print ("0048 | Swift cat                                       |")
print ("0049 | Most MLG scratch pro ever                       |")
print ("0050 | Five nights at scratch 2                        |")
print ("0051 | Super scratch                                   |")
print ("0052 | Space story                                     |")
print ("0053 | Plants vs. scratchies                           |")
print ("0054 | Turkey cooking                                  |")
print ("0055 | Space quest                                     |")
print ("0056 | Island survival                                 |")
print ("0057 | Untitled                                        |")
print ("0058 | Super scratch 2                                 |")
print ("0059 | Survival maximum                                |")
print ("0060 | MLG Halloween 2015                              |")
print ("0061 | Most MLG scratch project ever 2                 |")
print ("0062 | A day at the beach                              |")
print ("0063 | War of control                                  |")
print ("0064 | Game development studio                         |")
print ("0065 | Land of knowledge                               |")
print ("0066 | Island survival 2 the lost realm                |")
print ("0067 | Game studio                                     |")
print ("0068 | Casino story copy                               |")
print ("0069 | Farmpro premium                                 |")
print ("0070 | Derp                                            |")
print ("0071 | Untitled-2                                      |")
print ("0072 | Siege premium                                   |")
print ("0073 | Untitled-3                                      |")
print ("0074 | Fredbears pizza                                 |")
print ("0075 | Scratch explorer                                |")
print ("0076 | Castle story copy                               |")
print ("0077 | Scratch race                                    |")
print ("0078 | Turkey                                          |")
print ("0079 | Untitled-4                                      |")
print ("0080 | Untitled-5                                      |")
print ("0081 | MLG                                             |")
print ("0082 | Turkey run                                      |")
print ("0083 | Untitled-6                                      |")
print ("0084 | Scratch party                                   |")
print ("0085 | Castle story                                    |")
print ("0086 | Crossy scratch                                  |")
more1 = input("View 50 more [ENTER]")
print ("0087 | Anamatronica                                    |")
print ("0088 | I-restaurant                                    |")
print ("0089 | Guide the missile                               |")
print ("0090 | Band builder                                    |")
print ("0091 | Super hack                                      |")
print ("0092 | The scratch games                               |")
print ("0093 | Five Nights At Scratch 3 INDEV 1.8.24.5 copy    |")
print ("0094 | Alley maniac                                    |")
print ("0095 | Who Wants To Be A Trillionaire adventure version|")
print ("0096 | Plants vs. bad                                  |")
print ("0097 |
print ("0098 |
print ("0099 |
print ("0100 |
print ("0101 |
print ("0102 |
print ("0103 |
print ("0104 |
print ("0105 |
print ("0106 |
print ("0107 |
print ("0108 |
print ("0109 |
print ("0110 |
print ("0111 |
print ("0112 |
print ("0113 |
print ("0114 |
print ("0115 |
print ("0116 |
print ("0117 |
print ("0118 |
print ("0119 |
print ("0120 |
print ("0121 |
print ("0122 |
print ("0123 |
print ("0124 |
print ("0125 |
print ("0126 |
print ("0127 |
print ("0128 |
print ("0129 |
print ("0130 |
print ("0131 |
print ("0132 |
print ("0133 |
print ("0134 |
print ("0135 |
print ("0136 |
more1 = input("View 50 more [ENTER]")
print ("0137 |")
print ("0138 |")
print ("0139 |")
print ("0140 |")
search1 = str(input("Search a project before you leave? type a number 1 through 1336 or type 'about' \nOther commands:\t\tPattern"))
if (search1 == "1"):
	print ("seans epic trivia 5 trivia type challenge")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50803296/#editor")
	print ("Last modified: March 5th 2015")
	print ("Sean's very first scratch project")
if (search1 == "2"):
	print ("The maze")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50971922/#editor")
	print ("Last modified: March 5th 2015")
	print ("The second project by Sean, made to test the sensors of scratch with a mazde")
if (search1 == "3"):
	print ("Sean and Mitchell's puppy paradise movie")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51002926/#editor")
	print ("Last modified: March 6th 2015")
	print ("A test animation in scratch made by both Sean Myrick and Mitchell Myrick")
if (search1 == "4"):
	print ("Memes first scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51005040/#editor")
	print ("Last modified: March 6th 2015")
	print ("An incomplete scratch project made by Sean for his mom, Colleen (nicknamed meme)")
if (search1 == "5"):
	print ("Immortal combat dragon edition")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51269622/#editor")
	print ("Last modified: March 7th 2015")
	print ("An incomplete mortal combat clone with no research on mortal combat")
if (search1 == "6"):
	print ("Halloween")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50992280/#editor")
	print ("Last modified: March 6th 2015")
	print ("An abandoned halloween test animation")
if (search1 == "7"):
	print ("Super Scratch Pong 2")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51535330/#editor")
	print ("Last modified: March 9th 2015")
	print ("An abandoned pong project for Sean's 7th grade programming class")
if (search1 == "8"):
	print ("Defend the planet")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52199154/#editor")
	print ("Last modified: March 13th 2015")
	print ("A project based on a flash game about defending the planet [incomplete]")
if (search1 == "9"):
	print ("TRM quiz")
	print ("By @Seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52392282/#editor")
	print ("Last modified: March 14th 2015")
	print ("A quiz for Sean's old YouTube team TRM (The Iron Melon) incomplete project")
if (search1 == "10"):
	print ("Castle Siege Scratch")
	print ("By @Seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52396964/#editor")
	print ("Last modified: March 14th 2015")
	print ("A castle attack game demo made to test out some scratch graphics and blocks")
if (search1 == "11"):
	print ("Grand theft auto - scratch")
	print ("By @Seanspokanr2015")
	print ("Project URL: https://scratch.mit.edu/projects/52480582/#editor")
	print ("Last modified: March 14th 2015")
	print ("A basic grand theft auto fangame that never took off")
if (search1 == "12"):
	print ("The lab \"rat\"")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52496476/#editor")
	print ("Last modified: March 15th 2015")
	print ("A basic storygame that never took off")
if (search1 == "13"):
	print ("White house down")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52502716/#editor")
	print ("Last modified: March 15th 2015")
	print ("A useless animation of a scratch building sprite blowing up")
if (search1 == "14"):
	print ("Crossy scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51980866/#editor")
	print ("Last modified: March 11th 2015")
	print ("An incomplete crossy road clone based on the scratch sprite theme")
if (search1 == "15"):
	print ("I like trains fat edition")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50764974/#editor")
	print ("Last modified: March 4th 2015")
	print ("A stupid ASDF joke")
if (search1 == "16"):
	print ("Five nights at scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52393790/#editor")
	print ("Last modified: March 14th 2015")
	print ("A poorly made FNAF clone during my FNAF phase")
if (search1 == "17"):
	print ("NASA scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52496898/#editor")
	print ("Last modified: March 15th 2015")
	print ("An incomplete anti-gravity scratch space game with no set theme")
if (search1 == "18"):
	print ("Multiplication tables with scratch cat")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53372268/#editor")
	print ("Last modified: March 19th 2015")
	print ("Scratch cat explains the multiplication table poorly - yet another incomplete project")
if (search1 == "19"):
	print ("Bounce Party!!!!!!!!!!!!!!!!!!!!!!!!!!!")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53374040/#editor")
	print ("Last modified: March 19th 2015")
	print ("Sean found out the trampoline sprite and got carried away, just a scratch cat jumping on a trampoline project")
	print ("Comments")
	print ("You can tell this project is old, as this wasn't ironic and I used more than 3 exclamation points (I use up to a max of 3 exclamation points in a serious subject. If I am being ironic, sometimes I spam these")
	print ("Sean Myrick @ 12:31 PM on January 15th 2019")
if (search1 == "20"):
	print ("Gold rush!")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53375448/#editor")
	print ("Last modified: March 19th 2015")
	print ("An incomplete mining game with WACKY EFFECTS!!!!!")
if (search1 == "21"):
	print ("Turkey nightmare IV")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52602690/#editor")
	print ("Last modified: March 16th 2015")
	print ("An early viewing of my weird fetish - one of the first drawn occurences - turkey torture")
if (search1 == "22"):
	print ("Turkey simulator")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51378382/#editor")
	print ("Last modified: March 9th 2015")
	print ("A simulation of the torturous life of a turkey - what Sean used to think")
if (search1 == "23"):
	print ("Dodge the bullet - turkey edition")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51782342/#editor")
	print ("Last modified: March 11th 2015")
	print ("Try to avoid cannonfire and survive as a turkey")
if (search1 == "24"):
	print ("Don't shoot the turkey")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52186504/#editor")
	print ("Last modified: March 12th 2015")
	print ("A new abandoned version of \"Dodge the bullet\" By sean")
if (search1 == "25"):
	print ("Turkey stuffing")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52201472/#editor")
	print ("Last modified: March 13th 2015")
	print ("Sean recently saw and found out what a raw turkey is and what they do with it, and it upset him. This used to be a calming method")
if (search1 == "26"):
	print ("Si High Demo")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50787538/#editor")
	print ("Last modified: March 4th 2015")
	print ("Sean playing around with Scratch sprites, this week, Si")
if (search1 == "27"):
	print ("Dumb ways to scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50993518/#editor")
	print ("Last modified: March 6th 2015")
	print ("An incomplete parody of dumb ways to die")
	print ("Comments")
	print ("The name doesn't seem innocent anynore. It was originally just word mixing of scratch and dumb ways to die. Now it seems like a perverted name. My innocence is dead")
	print ("Sean Myrick @ 12:43 PM on January 15th 2019")
if (search1 == "28"):
	print ("Girl Game I")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52397548/#editor")
	print ("Last modified: March 14th 2015")
	print ("A game Sean made that seemed girlish to him (modern: silly)")
if (search1 == "29"):
	print ("Escape the prison - scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52397774/#editor")
	print ("Last modified: March 14th 2015")
	print ("A basic incomplete scratch parody of escape the prison")
if (search1 == "30"):
	print ("War surival")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51983992/#editor")
	print ("Last modified: March 12th 2015")
	print ("An escape game where you survive a war [as usual, incomplete]")
if (search1 == "31"):
	print ("rayco.com")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50972142/#editor")
	print ("Last modified: March 5th 2015")
	print ("A program based off of the old Dr. Ray series, one character of the abandoned TRM project")
if (search1 == "32"):
	print ("Super Scratch Pong 2015")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50766984/#editor")
	print ("Last modified: March 4th 2015")
	print ("An attempted remaster of my original pong game, still abandoned")
if (search1 == "33"):
	print ("Ancient Warfare I")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/52480364/#editor")
	print ("Last modified: March 14th 2015")
	print ("An abandoned ancient-themed battle game")
if (search1 == "34"):
	print ("Job career test")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51983786/#editor")
	print ("Last modified: March 12th 2015")
	print ("An abandoned Job career test application")
if (search1 == "35"):
	print ("Unlucky buttons")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50570780/#editor")
	print ("Last modified: March 3rd 2015")
	print ("Random buttons with random effects")
if (search1 == "36"):
	print ("Nuclear cat roadmine")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53694682/#editor")
	print ("Last modified: March 21st 2015")
	print ("Animation of scratch cat being nuked - I don't know why I made this")
if (search1 == "37"):
	print ("Uncle Unicapricornicopria")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53968966/#editor")
	print ("Last modified: March 23rd 2015")
	print ("Bad animation made since Sean was bored, based off Uncle Grandpa")
if (search1 == "38"):
	print ("Neon scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53969670/#editor")
	print ("Last modified: March 23rd 2015")
	print ("Scratch cat with a Neon effect")
if (search1 == "39"):
	print ("Lol cat")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53973194/#editor")
	print ("Last modified: March 23rd 2015")
	print ("A derpy scratch cat")
if (search1 == "40"):
	print ("Nauseator")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53999320/#editor")
	print ("Last modified: March 24th 2015")
	print ("Spinning spiral makes you dizzy")
if (search1 == "41"):
	print ("Instruments")
	print ("By @Seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/50969826/#editor")
	print ("Last modified: March 5th 2015")
	print ("Testing scratchs instrument sprites and sound samples")
if (search1 == "42"):
	print ("The sounds of scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/51992882/#editor")
	print ("Last modified: March 12th 2015")
	print ("A poor attempt to get all of scratch's sound effects into a soundboard")
if (search1 == "43"):
	print ("None direction band")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/54392732/#editor")
	print ("Last modified: March 25th 2015")
	print ("Another sound and sprite test (keep in mind, I wasn't fully aware of what one direction was when making this)")
if (search1 == "44"):
	print ("Die hard")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/54585622/#editor")
	print ("Last modified: March 26th 2015")
	print ("*NOT BASED ON THE MOVIE DIE HARD* I wasn't aware of that at the time. This is just another war survival game")
if (search1 == "45"):
	print ("Bomb simulator")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/54625700/#editor")
	print ("Last modified: March 27th 2015")
	print ("Just bomb animations, not a very good bomb simulator")
if (search1 == "46"):
	print ("Are you like sean quiz")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/54769944/#editor")
	print ("Last modified: March 27th 2015")
	print ("An incomplete quiz about Sean. ''Guess we will never know''")
if (search1 == "47"):
	print ("Swift cat")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/54773742/#editor")
	print ("Last modified: March 27th 2015")
	print ("Another random tweak to scratch cat. This time it's swift")
if (search1 == "48"):
	print ("Most MLG scratch project ever")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/60834686/#editor")
	print ("Last modified: May 6th 2015")
	print ("Based off ''the most MLG game ever'' not a very good clone. Also MLG was really popular in my middle school at the time so this was bound to happen eventually")
if (search1 == "49"):
	print ("Five nights at scratch 2")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/60839230/#editor")
	print ("Last modified: May 6th 2015")
	print ("Another FNAF game. This was during my FNAF phase")
if (search1 == "50"):
	print ("Super scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/63163944/#editor")
	print ("Last modified: May 19th 2015")
	print ("A platformer game to test platform programming. Very early start of my gravitational testing, not the best. Scratch themed")
if (search1 == "51"):
	print ("Space story")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/63166076/#editor")
	print ("Last modified: May 19th 2015")
	print ("A space story game, unfinished at the most, didn't go very far")
if (search1 == "52"):
	print ("Plants vs. scratchies")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/61926272/#editor")
	print ("Last modified: May 12th 2015")
	print ("This project was originally going to go on forever, but Sean got tired of it, and development stopped. This is a plants vs. zombies clone based off the Scratch theme")
if (search1 == "53"):
	print ("Turkey cooking")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/61092764/#editor")
	print ("Last modified: May 8th 2015")
	print ("Sean needed more coping to his turkey-related issues and this was made. Poorly drawn, and hard to watch, this simulation shows a turkey being cooked")
if (search1 == "54"):
	print ("Space quest")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/62324012/#editor")
	print ("Last modified: May 14th 2015") 
	print ("Another defend the planet clone, discontinued almost immediately due to boredom and lack of interest") 
if (search1 == "55"):
	print ("Island survival")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/63601986/#editor")
	print ("Last modified: May 21st 2015")
	print ("A sandbox island survival game, this led to the basis of an upcoming sandbox series, this was just a simple test of how to work with inventory, physics, and exploring. It was discontinued before it could take off")
if (search1 == "56"):
	print ("Untitled")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/63809634/#editor")
	print ("Last modified: May 22nd 2015")
	print ("Abandoned from the start, Sean didn't know what he was doing and made a random scratch cat sprite and didn't know what to do with it")
if (search1 == "57"):
	print ("Super scratch 2")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/63977388/#editor")
	print ("Last modified: May 24th 2015")
	print ("A discontinued clone of Super scratch, didn't make it that far as there was no plot. Right into the reject bin... as usual")
if (search1 == "58"):
	print ("Survival maximum")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/63977760/#editor")
	print ("Last modified: May 26th 2015")
	print ("A maximum security prison survival game, discontinued almost immediately. There was a lot of discontinuation at the start, as I kept learning more things that could be done with Scratch that should have been implemented at the start")
if (search1 == "59"):
	print ("MLG Halloween 2015")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64115308/#editor")
	print ("Last modified: May 26th 2015")
	print ("A poorly made MLG game, discontinued almost immediately")
if (search1 == "60"):
	print ("Most MLG scratch project ever 2")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64118296/#editor")
	print ("Last modified: May 26th 2015")
	print ("A poorly made sequel to \"Most MLG scratch project ever\"Discontinued as usual")
if (search1 == "61"):
	print ("A day at the beach")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64119628/#editor")
	print ("Last modified: May 26th 2015")
	print ("A quick animation about an adventure in a day at the beach")
if (search1 == "62"):
	print ("War of control")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64258888/#editor")
	print ("Last modified: May 26th 2015")
	print ("An abandoned project about a war over protecting a button")
if (search1 == "63"):
	print ("Game development studio")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64293664/#editor")
	print ("Last modified: May 27th 2015")
	print ("A simple sandbox game development studio, limited to a set of options, not much can really be done. Hey, at least it wasn't abandoned at the start")
if (search1 == "64"):
	print ("The land of knowledge")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64625926/#editor")
	print ("Last modified: May 28th 2015")
	print ("A school full of knowledge, a discontinued educational game")
if (search1 == "65"):
	print ("Island survival 2 - the lost realm")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64629492/#editor")
	print ("Last modified: May 28th 2015")
	print ("A sequel to \"Island survival\" That got discontinued almost immediately")
if (search1 == "66"):
	print ("Game studio")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64476220/#editor")
	print ("Last modified: May 28th 2015")
	print ("A small game studio adventure, that got discontinued very fast")
if (search1 == "67"):
	print ("Casino story copy")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64660304/#editor")
	print ("Last modified: May 28th 2015")
	print ("A casino development tycoon, run your own casino. This was actually a finished project, there just isn't much to do")
if (search1 == "68"):
	print ("Farmpro premium")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64789880/#editor")
	print ("Last modified: May 29th 2015")
	print ("A basic farming tycoon with 1 plot of soil. Cookie clicker farm edition, discontinued")
if (search1 == "69"):
	print ("Derp")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/53569080/#editor")
	print ("Last modified: March 20th 2015")
	print ("An animation with level -6 humor. If you find everything funny, then this is for you!")
if (search1 == "70"):
	print ("Untitled-2")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64977410/#editor")
	print ("Last modified: May 31st 2015")
	print ("Abandoned project, created by accident. Nothing was done with it except for paint a scratch cat green. There is nowhere else I wanted to go from here, unneccessary empty project :/")
if (search1 == "71"):
	print ("Siege premium")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64988570/#editor")
	print ("Last modified: May 31st 2015")
	print ("A vehicle driving game where you destroy stuff. A lot of these ideas really didn't have much to them, that is how I was able to put so many out in such short amounts of time. In the future of my scratch career, they get more complex, this is just API 1 of it")
if (search1 == "72"):
	print ("Untitled-3")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64988790/#editor")
	print ("Last modified: May 31st 2015")
	print ("Just scratch cat with a hat. Nothing spawned from this, just like untitled-2")
if (search1 == "73"):
	print ("Fredbears pizza")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/64991666/#editor")
	print ("Last modified: May 31st 2015")
	print ("A FNAF world game before FNAF world even existed. It wasn't a very good creation. It was during my FNAF phase, but this project just doesn't have much to it")
if (search1 == "74"):
	print ("Scratch explorer")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65360704/#editor")
	print ("Last modified: June 2nd 2015")
	print ("An explorer game with a working inventory. An early list test")
if (search1 == "75"):
	print ("Castle story copy")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65363012/#editor")
	print ("Last modified: June 2nd 2015")
	print ("Not a copy, and not a complete game. As usual, it was abandoned from the start")
if (search1 == "76"):
	print ("Scratch race")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65363086/#editor")
	print ("Last modified: June 2nd 2015")
	print ("A scratch racing game, movement functions test, not a complete program")
if (search1 == "77"):
	print ("Turkey")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65572548/#editor")
	print ("Last modified: June 3rd 2015")
	print ("A picture of a raw turkey. Sean wasn't feeling good. However, this is one of the first projects with images uploaded from Sean's computer, and not just drawn in Scratch or assets from scratch")
if (search1 == "78"):
	print ("Untitled-4")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65745306/#editor")
	print ("Last modified: June 4th 2015")
	print ("Sean was making a kitchen based game, but didn't like it that much. The image ruined it for him and the project was abandoned")
if (search1 == "79"):
	print ("Untitled-5")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65757208/#editor")
	print ("Last modified: June 4th 2015")
	print ("Partly-hand drawn animation of a turkey getting butchered. It didn't go through, as Sean got disturbed and quit")
if (search1 == "80"):
	print ("MLG")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65758064/#editor")
	print ("Last modified: June 4th 2015")
	print ("Accidental creation, just didn't delete. Accidentally renamed to MLG")
if (search1 == "81"):
	print ("Turkey run")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65773788/#editor")
	print ("Last modified: June 5th 2015")
	print ("Another turkey survival game, discontinued due to fear")
if (search1 == "82"):
	print ("Untitled-6")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/66072396/#editor")
	print ("Last modified: June 7th 2015")
	print ("An accidental project, scratch cat was removed, and we are left with a 480x360 white background. Well, let's say an attempt was *almost* made")
if (search1 == "83"):
	print ("Scratch party")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/66072934/#editor")
	print ("Last modified: June 7th 2015")
	print ("A basic party simulator with sprite animations from Scratch. Discontinued at the start")
if (search1 == "84"):
	print ("Castle story")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65362536/#editor")
	print ("Last modified: June 2nd 2015")
	print ("a continuation of Castle story with barely anything added. This was abandoned again")
if (search1 == "85"):
	print ("Something was skipped")
	print ("By @seanspokane2015")
	print ("Project URL: An error has occured")
	print ("Last modified: an error has occured")
	print ("Skipped project")
if (search1 == "86"):
	print ("Crossy scratch")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/63809882/#editor")
	print ("Last modified: May 22nd 2015")
	print ("A crossy road clone that failed from the start. Discontinued")
if (search1 == "87"):
	print ("Anamatronica")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65695854/#editor")
	print ("Last modified: June 4th 2015")
	print ("A sample FNAF demo game")
if (search1 == "88"):
	print ("I-restaurant")
	print ("By @seanspokane2015")
	print ("Project URL: https://scratch.mit.edu/projects/65566052/#editor")
	print ("Last modified: June 3rd 2015")
	print ("A restaurant story clone made to test 3D graphic skills. It didn't go very well :/")
if (search1 == "89"):
	print ("Guide the missile")
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "90"):
	print ("Band builder")
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "91"):
	print ("Super hack")
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "92"):
	print ("The scratch games")
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print ("
if (search1 == "93"):
	print ("Five Nights At Scratch 3 INDEV 1.8.24.5 copy")
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "94"):
	print ("Alley maniac")
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "95"):
	print ("Who Wants To Be A Trillionaire adventure version")
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "96"):
	print ("Plants vs. bad")
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print ("
if (search1 == "97"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print ("
if (search1 == "98"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "99"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "100"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "101"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "102"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "103"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "104"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "105"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "106"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "107"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print ("
if (search1 == "108"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 	
if (search1 == "109"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print ("
if (search1 == "110"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "111"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "112"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "113"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "114"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "115"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "116"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "117"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "118"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "119"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "120"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "121"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "122"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "123"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "124"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "125"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "126"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "127"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "128"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "129"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "130"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "131"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "132"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "133"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "134"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "135"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "136"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
if (search1 == "about" or search1 == "About" or search1 == "ABOUT" or search1 == "aBOUT"):
	print ("About")
	print ("This is a python based directory containing info for all scratch projects hosted on Sean's main scratch account")
if (search1 == "pattern" or search1 == "Pattern" or search1 == "PATTERN" or search1 == "pATTERN"):
	print ("last project pattern")
	print ("_________________________________")
	print ("| #    | date      | file | day |")
	print ("| 0036 | 1/14/2019 | SB3  | 01  |")
	print ("| 0086 | 1/15/2019 | SB3  | 02  |")
	print ("| 0136 | 1/16/2019 | SB3  | 03  |")
	print ("| 0186 | 1/17/2019 | SB3  | 04  |")
	print ("| 0236 | 1/18/2019 | SB3  | 05  |")
	print ("| 0286 | 1/19/2019 | SB3  | 06  |")
	print ("| 0336 | 1/20/2019 | SB3  | 07  |")
	print ("| 0386 | 1/21/2019 | SB3  | 08  |")
	print ("| 0436 | 1/22/2019 | SB3  | 09  |")
	print ("| 0486 | 1/23/2019 | SB3  | 10  |")
	print ("| 0536 | 1/24/2019 | SB3  | 11  |")
	print ("| 0586 | 1/25/2019 | SB3  | 12  |")
	print ("| 0636 | 1/26/2019 | SB3  | 13  |")
	print ("| 0686 | 1/27/2019 | SB3  | 14  |")
	print ("| 0736 | 1/28/2019 | SB3  | 15  |")
	print ("| 0786 | 1/29/2019 | SB3  | 16  |")
	print ("| 0836 | 1/30/2019 | SB3  | 17  |")
	print ("| 0886 | 1/31/2019 | SB3  | 18  |")
	print ("| 0936 | 2/01/2019 | SB3  | 19  |")
	print ("| 0986 | 2/02/2019 | SB3  | 20  |")
	print ("| 1036 | 2/03/2019 | SB3  | 21  |")
	print ("| 1086 | 2/04/2019 | SB3  | 22  |")
	print ("| 1136 | 2/05/2019 | SB3  | 23  |")
	print ("| 1186 | 2/06/2019 | SB3  | 24  |")
	print ("| 1236 | 2/07/2019 | SB3  | 25  |")
	print ("| 1286 | 2/08/2019 | SB3  | 26  |")
	print ("| 1336 | 2/09/2019 | SB3  | 27  |")
	print ("=================================")
	noMore = input("Press [ENTER] key to continue")
noMore = input("Those are all of Sean's scratch projects\nPress [ENTER] key to exit")
# Version 1.11
# January 15th 2019 build
'''
if (search1 == "86"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
'''