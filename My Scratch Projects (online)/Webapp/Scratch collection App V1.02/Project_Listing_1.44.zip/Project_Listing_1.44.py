print ("The Sean Walla Walla scratch archive")
print ("Since 2015")
print ("===============")
print ("Select a user: ")
print ("Seanspokane2015 (1)")
print ("Seanwallawalla (2)")
userSel = int(input(">> "))
if (userSel == 1):
	loopSpokane2015 = int(1)
	while (loopSpokane2015 == 1):
		print ("My scratch projects")
		print ("from scratch.mit.edu")
		print ("\n1336 items")
		print ("0001 | seans epic trivia 5 trivia type challenge       |")
		print ("0002 | The maze                                        |")
		print ("0003 | Sean and mitchells puppy paradise movie         |")
		print ("0004 | Meme's first scratch                            |")
		print ("0005 | immortal combat dragon version                  |")
		print ("0006 | Halloween                                       |")
		print ("0007 | Super Scratch Pong 2                            |")
		print ("0008 | Defend the planet                               |")
		print ("0009 | Archer I                                        |")
		print ("0010 | TRM Quiz                                        |")
		print ("0011 | Castle Siege Scratch                            |")
		print ("0012 | Grand Theft Auto - scratch                      |")
		print ("0013 | The lab \"rat\"                                   |")
		print ("0014 | White house down                                |")
		print ("0015 | Crossy scratch                                  |")
		print ("0016 | I like trains scratch edition                   |")
		print ("0017 | Five nights at scratch                          |")
		print ("0018 | NASA scratch                                    |")
		print ("0019 | Multiplication tables with scratch cat          |")
		print ("0020 | Bounce Party!!!!!!!!!!!!!!!!!!!!!!!!!!!         |")
		print ("0021 | Gold rush                                       |")
		print ("0022 | Turkey Nightmare IV                             |")
		print ("0023 | Turkey simulator                                |")
		print ("0024 | Dodge The Bullet -Turkey edition                |")
		print ("0025 | Don't shoot the turkey                          |")
		print ("0026 | Turkey stuffing                                 |")
		print ("0027 | Si high demo                                    |")
		print ("0028 | Dumb ways to scratch                            |")
		print ("0029 | Girl Game I                                     |")
		print ("0030 | Escape the prison - scratch                     |")
		print ("0031 | War survival                                    |")
		print ("0032 | Rayco.com                                       |")
		print ("0033 | Super scratch pong 2015                         |")
		print ("0034 | Ancient warfare I                               |")
		print ("0035 | Job career test                                 |")
		print ("0036 | Unlucky buttons                                 |")
		more1 = input("View 50 more [ENTER]")
		print ("0037 | Nuclear cat roadmine                            |")
		print ("0038 | Uncle Unicapricornicopria                       |")
		print ("0039 | Neon scratch                                    |")
		print ("0040 | Lol cat                                         |")
		print ("0041 | Nauseator                                       |")
		print ("0042 | Instruments                                     |")
		print ("0043 | The sounds of scratch                           |")
		print ("0044 | None direction band                             |")
		print ("0045 | Die hard                                        |")
		print ("0046 | Bomb simulator                                  |")
		print ("0047 | Are you like Sean quiz                          |")
		print ("0048 | Swift cat                                       |")
		print ("0049 | Most MLG scratch pro ever                       |")
		print ("0050 | Five nights at scratch 2                        |")
		print ("0051 | Super scratch                                   |")
		print ("0052 | Space story                                     |")
		print ("0053 | Plants vs. scratchies                           |")
		print ("0054 | Turkey cooking                                  |")
		print ("0055 | Space quest                                     |")
		print ("0056 | Island survival                                 |")
		print ("0057 | Untitled                                        |")
		print ("0058 | Super scratch 2                                 |")
		print ("0059 | Survival maximum                                |")
		print ("0060 | MLG Halloween 2015                              |")
		print ("0061 | Most MLG scratch project ever 2                 |")
		print ("0062 | A day at the beach                              |")
		print ("0063 | War of control                                  |")
		print ("0064 | Game development studio                         |")
		print ("0065 | Land of knowledge                               |")
		print ("0066 | Island survival 2 the lost realm                |")
		print ("0067 | Game studio                                     |")
		print ("0068 | Casino story copy                               |")
		print ("0069 | Farmpro premium                                 |")
		print ("0070 | Derp                                            |")
		print ("0071 | Untitled-2                                      |")
		print ("0072 | Siege premium                                   |")
		print ("0073 | Untitled-3                                      |")
		print ("0074 | Fredbears pizza                                 |")
		print ("0075 | Scratch explorer                                |")
		print ("0076 | Castle story copy                               |")
		print ("0077 | Scratch race                                    |")
		print ("0078 | Turkey                                          |")
		print ("0079 | Untitled-4                                      |")
		print ("0080 | Untitled-5                                      |")
		print ("0081 | MLG                                             |")
		print ("0082 | Turkey run                                      |")
		print ("0083 | Untitled-6                                      |")
		print ("0084 | Scratch party                                   |")
		print ("0085 | Castle story                                    |")
		print ("0086 | Crossy scratch                                  |")
		more1 = input("View 50 more [ENTER]")
		print ("0087 | Anamatronica                                    |")
		print ("0088 | I-restaurant                                    |")
		print ("0089 | Guide the missile                               |")
		print ("0090 | Band builder                                    |")
		print ("0091 | Super hack                                      |")
		print ("0092 | The scratch games                               |")
		print ("0093 | Five Nights At Scratch 3 INDEV 1.8.24.5 copy    |")
		print ("0094 | Alley maniac                                    |")
		print ("0095 | Who Wants To Be A Trillionaire adventure version|")
		print ("0096 | Plants vs. bad                                  |")
		print ("0097 | Plants battles                                  |")
		print ("0098 | Ultrascratch                                    |")
		print ("0099 | Scratch comix copy                              |")
		print ("0100 | Sweggy man adventures 1                         |")
		print ("0101 | Brain tricker                                   |")
		print ("0102 | Untitled-7                                      |")
		print ("0103 | MLG                                             |")
		print ("0104 | Untitled-8                                      |")
		print ("0105 | Casino story 2                                  |")
		print ("0106 | Turkey stories                                  |")
		print ("0107 | MLG journeys                                    |")
		print ("0108 | Plants vs. scratchies ALPHA 1.0                 |")
		print ("0109 | Immortal combat                                 |")
		print ("0110 | Scrolls seanwallawalla edition                  |")
		print ("0111 | Street builder                                  |")
		print ("0112 | Night mode app                                  |")
		print ("0113 | The seanwallawalla app                          |")
		print ("0114 | Seans torture                                   |")
		print ("0115 | Untitled-9                                      |")
		print ("0116 | Gobo army                                       |")
		print ("0117 | Scratch journey                                 |")
		print ("0118 | Turkey defense 2                                |")
		print ("0119 | Memes memes of anenememes                       |")
		print ("0120 | The sean walla walla app                        |")
		print ("0121 | World of survival                               |")
		print ("0122 | Techlaration test selector                      |")
		print ("0123 | Stick figures                                   |")
		print ("0124 | Zombie siege                                    |")
		print ("0125 | U                                               |")
		print ("0126 | store story                                     |")
		print ("0127 | My scratch cat                                  |")
		print ("0128 | Rasple Operating System version 1.1.0 copy      |")
		print ("0129 | Band music card version 1                       |")
		print ("0130 | raspberry fever beta 1.2.6                      |")
		print ("0131 | Turkey hop                                      |")
		print ("0132 | Get rekt anna                                   |")
		print ("0133 | Insanity pong                                   |")
		print ("0134 | What I learned in scratch 2015                  |")
		print ("0135 | Christmas 2015                                  |")
		print ("0136 | Turkey dinner                                   |")
		more1 = input("View 50 more [ENTER]")
		print ("0137 | Seizure pro                                     |")
		print ("0138 | Funny scratch moments part 2                    |")
		print ("0139 | Funny scratch moments part 1                    |")
		print ("0140 | extremely awkward splash plane attack           |")
		print ("0141 | all about me                                    |")
		print ("0142 | Rasple Operating System version 1.1.1           |")
		print ("0143 | Five nights at scratch 3 night 4                |")
		print ("0144 | Jurassic universe                               |")
		print ("0145 | Turkey oven 1.4.2                               |")
		print ("0146 | Scratch TV demo                                 |")
		print ("0147 | Knight journey demo                             |")
		print ("0148 | Turkey simulator 1.5.4                          |")
		print ("0149 | Turkey defense                                  |")
		print ("0150 | scratchtastic demo                              |") 
		print ("0151 | Scrub wrecker                                   |")
		print ("0152 | Turkey simulator                                |")
		print ("0153 | Sea tales                                       |")
		print ("0154 | Dumb ways to die - turkey edition               |")
		print ("0155 | Turkey nightmare II                             |")
		print ("0156 | Turkey nightmare III                            |")
		print ("0157 | Turkey nightmare I                              |")
		print ("0158 | The scratcher                                   |")
		print ("0159 | Hospital quest demo                             |")
		print ("0160 | untitled-10                                     |")
		print ("0161 | TRM Galaxy of code version 1 copy               |")
		print ("0162 | Mass destruction                                |")
		print ("0163 | Untitled-11                                     |")
		print ("0164 | TRM Galaxy of code version 1                    |")
		print ("0165 | TRM Quiz                                        |")
		print ("0166 | Five Nights At Freddys Reborn demo 1.1 -2       |")
		print ("0167 | Five Nights At Freddys Reborn demo 1.0          |")
		print ("0168 | Five Nights At Freddys Reborn demo 1.1.1-2      |")
		print ("0169 | Five Nights At Freddys Memes 1.1 copy           |")
		print ("0170 | Five Nights At Freddys Memes 1.1                |")
		print ("0171 | Five Nights At Freddys Reborn demo 1.1.1 copy   |")
		print ("0172 | Five Nights At Freddys Reborn demo 1.1.1        |")
		print ("0173 | Five nights at freddys 3                        |")
		print ("0174 | Scratch run                                     |")
		print ("0175 | Clash Of Clans Memes 1.0 copy                   |")
		print ("0176 | Clash Of Clans Memes 1.0                        |")
		print ("0177 | Daily memes 1.0 copy                            |")
		print ("0178 | Grand theft scratch 1                           |")
		print ("0179 | Family guy memes 1.0 copy                       |")
		print ("0180 | Family guy memes 1.1                            |")
		print ("0181 | Five nights at freddys meme 1.0 redo            |")
		print ("0182 | Daily memes 1.0                                 |")
		print ("0183 | Formula 75 racing                               |")
		print ("0184 | Scratch help guide                              |")
		print ("0185 | Bug life                                        |")
		print ("0186 | Scratch go!                                     |")
		more1 = input("View 50 more [ENTER]")
		print ("0187 |")
		print ("0188 |")
		print ("0189 |")
		print ("0190 |")
		print ("0191 |")
		print ("0192 |")
		print ("0193 |")
		print ("0194 |")
		print ("0195 |")
		print ("0196 |")
		print ("0197 |")
		print ("0198 |")
		print ("0199 |")
		print ("0200 |")
		#----------------| start of variable list |----------------#
		# project 1 of 1336
		projectA1ViewCount = int(1)
		projectA1LikeCount = int(0)
		projectA1FavCount = int(0)
		# project 2 of 1336
		projectA2ViewCount = int(1)
		projectA2LikeCount = int(0)
		projectA2FavCount = int(0)
		# project 3 of 1336
		projectA3ViewCount = int(1)
		projectA3LikeCount = int(0)
		projectA3FavCount = int(0)
		# project 4 of 1336
		projectA4ViewCount = int(1)
		projectA4ikeCount = int(0)
		projectA4FavCount = int(0)
		# project 5 of 1336
		projectA5ViewCount = int(1)
		projectA5LikeCount = int(0)
		projectA5FavCount = int(0)
		# project 6 of 1336
		projectA6ViewCount = int(1)
		projectA6LikeCount = int(0)
		projectA6FavCount = int(0)
		# project 7 of 1336
		projectA7ViewCount = int(1)
		projectA7LikeCount = int(0)
		projectA7FavCount = int(0)
		# project 8 of 1336
		projectA8ViewCount = int(1)
		projectA8LikeCount = int(0)
		projectA8FavCount = int(0)
		# project 9 of 1336
		projectA9ViewCount = int(1)
		projectA9LikeCount = int(0)
		projectA9FavCount = int(0)
		# project 10 of 1336
		projectA10ViewCount = int(1)
		projectA10LikeCount = int(0)
		projectA10FavCount = int(0)
		# project 11 of 1336
		projectA11ViewCount = int(1)
		projectA11LikeCount = int(0)
		projectA11FavCount = int(0)
		# project 12 of 1336
		projectA12ViewCount = int(1)
		projectA12LikeCount = int(0)
		projectA12FavCount = int(0)
		# project 13 of 1336
		projectA13ViewCount = int(1)
		projectA13LikeCount = int(0)
		projectA13FavCount = int(0)
		# project 14 of 1336
		projectA14ViewCount = int(1)
		projectA14LikeCount = int(0)
		projectA14FavCount = int(0)
		# project 15 of 1336
		projectA15ViewCount = int(1)
		projectA15LikeCount = int(0)
		projectA15FavCount = int(0)
		# project 16 of 1336
		projectA16ViewCount = int(1)
		projectA16LikeCount = int(0)
		projectA16FavCount = int(0)
		# project 17 of 1336
		projectA17ViewCount = int(1)
		projectA17LikeCount = int(0)
		projectA17FavCount = int(0)
		# project 18 of 1336
		projectA18ViewCount = int(1)
		projectA18LikeCount = int(0)
		projectA18FavCount = int(0)
		# project 19 of 1336
		projectA19ViewCount = int(1)
		projectA19LikeCount = int(0)
		projectA19FavCount = int(0)
		# project 20 of 1336 
		projectA20ViewCount = int(1)
		projectA20LikeCount = int(0)
		projectA20FavCount = int(0)
		# project 21 of 1336
		projectA21ViewCount = int(1)
		projectA21LikeCount = int(0)
		projectA21FavCount = int(0)
		# project 22 of 1336
		projectA22ViewCount = int(1)
		projectA22LikeCount = int(0)
		projectA22FavCount = int(0)
		# project 23 of 1336
		projectA23ViewCount = int(1)
		projectA23LikeCount = int(0)
		projectA23FavCount = int(0)
		# project 24 of 1336
		projectA24ViewCount = int(1)
		projectA24LikeCount = int(0)
		projectA24FavCount = int(0)
		# project 25 of 1336
		projectA25ViewCount = int(1)
		projectA25LikeCount = int(0)
		projectA25FavCount = int(0)
		# project 26 of 1336
		projectA26ViewCount = int(1)
		projectA26LikeCount = int(0)
		projectA26FavCount = int(0)
		# project 27 of 1336
		projectA27ViewCount = int(1)
		projectA27LikeCount = int(0)
		projectA27FavCount = int(0)
		# project 28 of 1336
		projectA28ViewCount = int(1)
		projectA28LikeCount = int(0)
		projectA28FavCount = int(0)
		# project 29 of 1336
		projectA29ViewCount = int(1)
		projectA29LikeCount = int(0)
		projectA29FavCount = int(0)
		# project 30 of 1336
		projectA30ViewCount = int(1)
		projectA30LikeCount = int(0)
		projectA30FavCount = int(0)
		# project 31 of 1336
		projectA31ViewCount = int(1)
		projectA31LikeCount = int(0)
		projectA31FavCount = int(0)
		# project 32 of 1336
		projectA32ViewCount = int(1)
		projectA32LikeCount = int(0)
		projectA32FavCount = int(0)
		# project 33 of 1336
		projectA33ViewCount = int(1)
		projectA33LikeCount = int(0)
		projectA33FavCount = int(0)
		# project 34 of 1336
		projectA34ViewCount = int(1)
		projectA34LikeCount = int(0)
		projectA34FavCount = int(0)
		# project 35 of 1336
		projectA35ViewCount = int(1)
		projectA35LikeCount = int(0)
		projectA35FavCount = int(0)
		# project 36 of 1336
		projectA36ViewCount = int(1)
		projectA36LikeCount = int(0)
		projectA36FavCount = int(0)
		# project 37 of 1336
		projectA37ViewCount = int(1)
		projectA37LikeCount = int(0)
		projectA37FavCount = int(0)
		# project 38 of 1336
		projectA38ViewCount = int(1)
		projectA38LikeCount = int(0)
		projectA38FavCount = int(0)
		# project 39 of 1336
		projectA39ViewCount = int(1)
		projectA39LikeCount = int(0)
		projectA39FavCount = int(0)
		# project 40 of 1336
		projectA40ViewCount = int(1)
		projectA40ikeCount = int(0)
		projectA40FavCount = int(0)
		# project 41 of 1336
		projectA41ViewCount = int(1)
		projectA41ikeCount = int(0)
		projectA41FavCount = int(0)
		# project 42 of 1336
		projectA42ViewCount = int(1)
		projectA42ikeCount = int(0)
		projectA42FavCount = int(0)
		# project 43 of 1336
		projectA43ViewCount = int(1)
		projectA43ikeCount = int(0)
		projectA43FavCount = int(0)
		# project 44 of 1336
		projectA44ViewCount = int(1)
		projectA44ikeCount = int(0)
		projectA44FavCount = int(0)
		# project 45 of 1336
		projectA45ViewCount = int(1)
		projectA45ikeCount = int(0)
		projectA45FavCount = int(0)
		# project 46 of 1336
		projectA46ViewCount = int(1)
		projectA46ikeCount = int(0)
		projectA46FavCount = int(0)
		# project 47 of 1336
		projectA47ViewCount = int(1)
		projectA47ikeCount = int(0)
		projectA47FavCount = int(0)
		# project 48 of 1336
		projectA48ViewCount = int(1)
		projectA48ikeCount = int(0)
		projectA48FavCount = int(0)
		# project 49 of 1336
		projectA49ViewCount = int(1)
		projectA49ikeCount = int(0)
		projectA49FavCount = int(0)
		# project 50 of 1336
		projectA50ViewCount = int(1)
		projectA50LikeCount = int(0)
		projectA50FavCount = int(0)
		# project 51 of 1336
		projectA51ViewCount = int(1)
		projectA51LikeCount = int(0)
		projectA51FavCount = int(0)
		# project 52 of 1336
		projectA52ViewCount = int(1)
		projectA52LikeCount = int(0)
		projectA52FavCount = int(0)
		# project 53 of 1336
		projectA53ViewCount = int(1)
		projectA53LikeCount = int(0)
		projectA53FavCount = int(0)
		# project 54 of 1336
		projectA54ViewCount = int(1)
		projectA54LikeCount = int(0)
		projectA54FavCount = int(0)
		# project 55 of 1336
		projectA55ViewCount = int(1)
		projectA55LikeCount = int(0)
		projectA55FavCount = int(0)
		# project 56 of 1336
		projectA56ViewCount = int(1)
		projectA56LikeCount = int(0)
		projectA56FavCount = int(0)
		# project 57 of 1336
		projectA57ViewCount = int(1)
		projectA57LikeCount = int(0)
		projectA57FavCount = int(0)
		# project 58 of 1336
		projectA58ViewCount = int(1)
		projectA58LikeCount = int(0)
		projectA58FavCount = int(0)
		# project 59 of 1336
		projectA59ViewCount = int(1)
		projectA59LikeCount = int(0)
		projectA59FavCount = int(0)
		# project 60 of 1336
		projectA60ViewCount = int(1)
		projectA60LikeCount = int(0)
		projectA60FavCount = int(0)
		# project 61 of 1336
		projectA61ViewCount = int(1)
		projectA61LikeCount = int(0)
		projectA61FavCount = int(0)
		# project 62 of 1336
		projectA62ViewCount = int(1)
		projectA62LikeCount = int(0)
		projectA62FavCount = int(0)
		# project 63 of 1336
		projectA63ViewCount = int(1)
		projectA63LikeCount = int(0)
		projectA63FavCount = int(0)
		# project 64 of 1336
		projectA64ViewCount = int(1)
		projectA64LikeCount = int(0)
		projectA64FavCount = int(0)
		# project 65 of 1336
		projectA65ViewCount = int(1)
		projectA65LikeCount = int(0)
		projectA65FavCount = int(0)
		# project 66 of 1336
		projectA66ViewCount = int(1)
		projectA66LikeCount = int(0)
		projectA66FavCount = int(0)
		# project 67 of 1336
		projectA67ViewCount = int(1)
		projectA67LikeCount = int(0)
		projectA67FavCount = int(0)
		# project 68 of 1336
		projectA68ViewCount = int(1)
		projectA68LikeCount = int(0)
		projectA68FavCount = int(0)
		# project 69 of 1336
		projectA69ViewCount = int(1)
		projectA69LikeCount = int(0)
		projectA69FavCount = int(0)
		# project 70 of 1336
		projectA70ViewCount = int(1)
		projectA70LikeCount = int(0)
		projectA70FavCount = int(0)
		# project 71 of 1336
		projectA71ViewCount = int(1)
		projectA71LikeCount = int(0)
		projectA71FavCount = int(0)
		# project 72 of 1336
		projectA72ViewCount = int(1)
		projectA72LikeCount = int(0)
		projectA72FavCount = int(0)
		# project 73 of 1336
		projectA73ViewCount = int(1)
		projectA73LikeCount = int(0)
		projectA73FavCount = int(0)
		# project 74 of 1336
		projectA74ViewCount = int(1)
		projectA74LikeCount = int(0)
		projectA74FavCount = int(0)
		# project 75 of 1336
		projectA75ViewCount = int(1)
		projectA75LikeCount = int(0)
		projectA75FavCount = int(0)
		# project 76 of 1336
		projectA76ViewCount = int(1)
		projectA76LikeCount = int(0)
		projectA76FavCount = int(0)
		# project 77 of 1336
		projectA77ViewCount = int(1)
		projectA77LikeCount = int(0)
		projectA77FavCount = int(0)
		# project 78 of 1336
		projectA78ViewCount = int(1)
		projectA78LikeCount = int(0)
		projectA78FavCount = int(0)
		# project 79 of 1336
		projectA79ViewCount = int(1)
		projectA79LikeCount = int(0)
		projectA79FavCount = int(0)
		# project 80 of 1336
		projectA80ViewCount = int(1)
		projectA80LikeCount = int(0)
		projectA80FavCount = int(0)
		# project 81 of 1336
		projectA81ViewCount = int(1)
		projectA81LikeCount = int(0)
		projectA81FavCount = int(0)
		# project 82 of 1336
		projectA82ViewCount = int(1)
		projectA82LikeCount = int(0)
		projectA82FavCount = int(0)
		# project 83 of 1336
		projectA83ViewCount = int(1)
		projectA83LikeCount = int(0)
		projectA83FavCount = int(0)
		# project 84 of 1336
		projectA84ViewCount = int(1)
		projectA84LikeCount = int(0)
		projectA84FavCount = int(0)
		# project 85 of 1336
		projectA85ViewCount = int(1)
		projectA85LikeCount = int(0)
		projectA85FavCount = int(0)
		# project 86 of 1336
		projectA86ViewCount = int(1)
		projectA86LikeCount = int(0)
		projectA86FavCount = int(0)
		# project 87 of 1336
		projectA87ViewCount = int(1)
		projectA87LikeCount = int(0)
		projectA87FavCount = int(0)
		# project 88 of 1336
		projectA88ViewCount = int(1)
		projectA88LikeCount = int(0)
		projectA88FavCount = int(0)
		# project 89 of 1336
		projectA89ViewCount = int(1)
		projectA89LikeCount = int(0)
		projectA89FavCount = int(0)
		# project 90 of 1336
		projectA90ViewCount = int(1)
		projectA90LikeCount = int(0)
		projectA90FavCount = int(0)
		# project 91 of 1336
		projectA91ViewCount = int(1)
		projectA91LikeCount = int(0)
		projectA91FavCount = int(0)
		# project 92 of 1336
		projectA92ViewCount = int(1)
		projectA92LikeCount = int(0)
		projectA92FavCount = int(0)
		# project 93 of 1336
		projectA93ViewCount = int(1)
		projectA93LikeCount = int(0)
		projectA93FavCount = int(0)
		# project 94 of 1336
		projectA94ViewCount = int(1)
		projectA94LikeCount = int(0)
		projectA94FavCount = int(0)
		# project 95 of 1336
		projectA95ViewCount = int(1)
		projectA95LikeCount = int(0)
		projectA95FavCount = int(0)
		# project 96 of 1336
		projectA96ViewCount = int(1)
		projectA96LikeCount = int(0)
		projectA96FavCount = int(0)
		# project 97 of 1336
		projectA97ViewCount = int(1)
		projectA97LikeCount = int(0)
		projectA97FavCount = int(0)
		# project 98 of 1336
		projectA98ViewCount = int(1)
		projectA98LikeCount = int(0)
		projectA98FavCount = int(0)
		# project 99 of 1336
		projectA99ViewCount = int(1)
		projectA99LikeCount = int(0)
		projectA99FavCount = int(0)
		# project 100 of 1336
		projectA100ViewCount = int(1)
		projectA100LikeCount = int(0)
		projectA100FavCount = int(0)
		# project 101 of 1336
		projectA101ViewCount = int(1)
		projectA101LikeCount = int(0)
		projectA101FavCount = int(0)
		# project 102 of 1336
		projectA102ViewCount = int(1)
		projectA102LikeCount = int(0)
		projectA102FavCount = int(0)
		# project 103 of 1336
		projectA103ViewCount = int(1)
		projectA103LikeCount = int(0)
		projectA103FavCount = int(0)
		# project 104 of 1336
		projectA104ViewCount = int(1)
		projectA104LikeCount = int(0)
		projectA104FavCount = int(0)
		# project 105 of 1336
		projectA105ViewCount = int(1)
		projectA105LikeCount = int(0)
		projectA105FavCount = int(0)
		# project 106 of 1336
		projectA106ViewCount = int(1)
		projectA106LikeCount = int(0)
		projectA106FavCount = int(0)
		# project 107 of 1336
		projectA107ViewCount = int(1)
		projectA107LikeCount = int(0)
		projectA107FavCount = int(0)
		# project 108 of 1336
		projectA108ViewCount = int(1)
		projectA108LikeCount = int(0)
		projectA108FavCount = int(0)
		#-----------------| end of variable list |-----------------#
		search1 = str(input("Search a project before you leave? type a number 1 through 1336 or type 'about' \nOther commands:\t\tPattern"))
		if (search1 == "1"):
			print ("seans epic trivia 5 trivia type challenge")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50803296/#editor")
			print ("Last modified: March 5th 2015")
			print ("Sharing status: never shared")
			print ("View count: " + str(projectA1ViewCount))
			print ("Like count:  " + str(projectA1LikeCount))
			print ("Favorite count: " + str(projectA1FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 3.5/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 16 Megabytes")
			print ("Inspired by: class activity to show who we are")
			print ("Genre: school project")
			print ("Category: personal presentations")
			print ("Finish status: Finished")
			print ("Based off: Personal Trivia project")
			print ("File size: 1,164,910 bytes (1,164.9 Kilobytes) (1.16 Megabytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean's very first scratch project")
		if (search1 == "2"):
			print ("The maze")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50971922/#editor")
			print ("Last modified: March 5th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA2ViewCount))
			print ("Like count:  " + str(projectA2LikeCount))
			print ("Favorite count: " + str(projectA2FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 3.9/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 24 Megabytes")
			print ("Inspired by: Experimenting with sensors in scratch")
			print ("Genre: Puzzles")
			print ("Category: Sensors and puzzles")
			print ("Finish status: incomplete")
			print ("Based off: making mazes to test sensors")
			print ("File size: 6,731 bytes (6.73 Kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("The second project by Sean, made to test the sensors of scratch with a mazde")
		if (search1 == "3"):
			print ("Sean and Mitchell's puppy paradise movie")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51002926/#editor")
			print ("Last modified: March 6th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA3ViewCount))
			print ("Like count:  " + str(projectA3LikeCount))
			print ("Favorite count: " + str(projectA3FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by: Making a game with my brother Mitchell")
			print ("Genre: Stories and animation")
			print ("Category: Gaming story")
			print ("Finish status: Finished")
			print ("Based off: Making a program with my brother Mitchell")
			print ("File size: 2,726,896 bytes (2,726.89 Kilobytes) (2.72 Megabytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A test animation in scratch made by both Sean Myrick and Mitchell Myrick")
		if (search1 == "4"):
			print ("Memes first scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51005040/#editor")
			print ("Last modified: March 6th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA4ViewCount))
			print ("Like count:  " + str(projectA4LikeCount))
			print ("Favorite count: " + str(projectA4FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 1.0/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 16 Megabytes")
			print ("Inspired by: wanting to make a scratch account for my mom")
			print ("Genre: Family projects")
			print ("Category: Demonstration")
			print ("Finish status: finished, but never continued")
			print ("Based off: Making a project for my mom")
			print ("File size: 43,193 bytes (43.19 Kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete scratch project made by Sean for his mom, Colleen (nicknamed meme)")
		if (search1 == "5"):
			print ("Immortal combat dragon edition")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51269622/#editor")
			print ("Last modified: March 7th 2015")
			print ("Sharing status: ntt shared")
			print ("View count: " + str(projectA5ViewCount))
			print ("Like count:  " + str(projectA5LikeCount))
			print ("Favorite count: " + str(projectA5FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 7+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 64 megabytes")
			print ("Inspired by: Fighting based games")
			print ("Genre: Gaming")
			print ("Category: Battle games")
			print ("Finish status: never finished")
			print ("Based off: Mortal combat")
			print ("File size: 46,849 bytes (46.84 kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete mortal combat clone with no research on mortal combat")
		if (search1 == "6"):
			print ("Halloween")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50992280/#editor")
			print ("Last modified: March 6th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA6ViewCount))
			print ("Like count:  " + str(projectA6LikeCount))
			print ("Favorite count: " + str(projectA6FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 2.8/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by: Halloween sprites in scratch")
			print ("Genre: Animation")
			print ("Category: Holiday animations")
			print ("Finish status: not finished")
			print ("Based off: sprite testin")
			print ("File size: 216,703 bytes (216.70 Kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An abandoned halloween test animation")
		if (search1 == "7"):
			print ("Super Scratch Pong 2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51535330/#editor")
			print ("Last modified: March 9th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA7ViewCount))
			print ("Like count:  " + str(projectA7LikeCount))
			print ("Favorite count: " + str(projectA7FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 48 Megabytes")
			print ("Inspired by: Pong project for school")
			print ("Genre: Gaming")
			print ("Category: Retro games")
			print ("Finish status: Not finished")
			print ("Based off: Pong project for school")
			print ("File size: 5,597 bytes (5.59 Kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An abandoned pong project for Sean's 7th grade programming class")
		if (search1 == "8"):
			print ("Defend the planet")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52199154/#editor")
			print ("Last modified: March 13th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA8ViewCount))
			print ("Like count:  " + str(projectA8LikeCount))
			print ("Favorite count: " + str(projectA8FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 8+")
			print ("Personal rating: 4.0/5.0")
			print ("Original tags:  <none>")
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by: A flash game")
			print ("Genre: Gaming")
			print ("Category: Flash games")
			print ("Finish status: Not finished")
			print ("Based off: Planet defender (flash game)")
			print ("File size: 6,701 bytes (6.70 Kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A project based on a flash game about defending the planet [incomplete]")
		if (search1 == "9"):
			print ("Archer I")
			print ("By @seanspokane2015")
			print ("Project URL: ")
			print ("Last modified: January 16th 2019 (by accident)")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 8+")
			print ("Personal rating: 3.4/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 72 Megabytes")
			print ("Inspired by: Archery")
			print ("Genre: Shooting gams")
			print ("Category: Archer games")
			print ("Finish status: not finished")
			print ("Based off: Archery practice")
			print ("File size: 6,462 bytes (6.42 Kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Skipped project")
		if (search1 == "10"):
			print ("TRM quiz")
			print ("By @Seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52392282/#editor")
			print ("Last modified: March 14th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA10ViewCount))
			print ("Like count:  " + str(projectA10LikeCount))
			print ("Favorite count: " + str(projectA10FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 7+")
			print ("Personal rating: 3.1/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 72 Megabytes")
			print ("Inspired by: TRM team")
			print ("Genre: Quizzes and surveys")
			print ("Category: community quizzes")
			print ("Finish status: not finished")
			print ("Based off: My old YouTube community team, TRM, based off dantdm's Team TDM")
			print ("File size: 48,874 bytes (48.87 kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A quiz for Sean's old YouTube team TRM (The Iron Melon) incomplete project")
		if (search1 == "11"):
			print ("Castle Siege Scratch")
			print ("By @Seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52396964/#editor")
			print ("Last modified: March 14th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA11ViewCount))
			print ("Like count:  " + str(projectA11LikeCount))
			print ("Favorite count: " + str(projectA11FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 7+")
			print ("Personal rating: 3.1/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by: Castle and medievel scratch sprites")
			print ("Genre: Game testing")
			print ("Category: Medievel gaming")
			print ("Finish status: not finished")
			print ("Based off: a project to test out medievel scratch sprites")
			print ("File size: 1,443,316 bytes (1,443.31 kilobytes) (1.44 Megabytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A castle attack game demo made to test out some scratch graphics and blocks")
		if (search1 == "12"):
			print ("Grand theft auto - scratch")
			print ("By @Seanspokanr2015")
			print ("Project URL: https://scratch.mit.edu/projects/52480582/#editor")
			print ("Last modified: March 14th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA12ViewCount))
			print ("Like count:  " + str(projectA12LikeCount))
			print ("Favorite count: " + str(projectA12FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 10+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 64 megabytes")
			print ("Inspired by: Grand Theft Auto series")
			print ("Genre: gaming")
			print ("Category: Gaming")
			print ("Finish status: not finished")
			print ("Based off: Grand theft auto")
			print ("File size: 145,978 bytes (145.97 Kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A basic grand theft auto fangame that never took off")
		if (search1 == "13"):
			print ("The lab \"rat\"")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52496476/#editor")
			print ("Last modified: March 15th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA13ViewCount))
			print ("Like count:  " + str(projectA13LikeCount))
			print ("Favorite count: " + str(projectA13FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.1/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by: Story games")
			print ("Genre: Story gaming")
			print ("Category: Adventure games")
			print ("Finish status: not finished")
			print ("Based off: Original work (story about a laboratory")
			print ("File size: 856,576 bytes (856.57 Kilobytes)")
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A basic storygame that never took off")
		if (search1 == "14"):
			print ("White house down")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52502716/#editor")
			print ("Last modified: March 15th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A useless animation of a scratch building sprite blowing up")
		if (search1 == "15"):
			print ("Crossy scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51980866/#editor")
			print ("Last modified: March 11th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete crossy road clone based on the scratch sprite theme")
		if (search1 == "16"):
			print ("I like trains fat edition")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50764974/#editor")
			print ("Last modified: March 4th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A stupid ASDF joke")
		if (search1 == "17"):
			print ("Five nights at scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52393790/#editor")
			print ("Last modified: March 14th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A poorly made FNAF clone during my FNAF phase")
		if (search1 == "18"):
			print ("NASA scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52496898/#editor")
			print ("Last modified: March 15th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete anti-gravity scratch space game with no set theme")
		if (search1 == "19"):
			print ("Multiplication tables with scratch cat")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53372268/#editor")
			print ("Last modified: March 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Scratch cat explains the multiplication table poorly - yet another incomplete project")
		if (search1 == "20"): # continue renaming #s here
			print ("Bounce Party!!!!!!!!!!!!!!!!!!!!!!!!!!!")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53374040/#editor")
			print ("Last modified: March 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean found out the trampoline sprite and got carried away, just a scratch cat jumping on a trampoline project")
			print ("Comments")
			print ("You can tell this project is old, as this wasn't ironic and I used more than 3 exclamation points (I use up to a max of 3 exclamation points in a serious subject. If I am being ironic, sometimes I spam these")
			print ("Sean Myrick @ 12:31 PM on January 15th 2019")
		if (search1 == "20"):
			print ("Gold rush!")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53375448/#editor")
			print ("Last modified: March 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete mining game with WACKY EFFECTS!!!!!")
		if (search1 == "21"):
			print ("Turkey nightmare IV")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52602690/#editor")
			print ("Last modified: March 16th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An early viewing of my weird fetish - one of the first drawn occurences - turkey torture")
		if (search1 == "22"):
			print ("Turkey simulator")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51378382/#editor")
			print ("Last modified: March 9th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A simulation of the torturous life of a turkey - what Sean used to think")
		if (search1 == "23"):
			print ("Dodge the bullet - turkey edition")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51782342/#editor")
			print ("Last modified: March 11th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Try to avoid cannonfire and survive as a turkey")
		if (search1 == "24"):
			print ("Don't shoot the turkey")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52186504/#editor")
			print ("Last modified: March 12th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A new abandoned version of \"Dodge the bullet\" By sean")
		if (search1 == "25"):
			print ("Turkey stuffing")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52201472/#editor")
			print ("Last modified: March 13th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean recently saw and found out what a raw turkey is and what they do with it, and it upset him. This used to be a calming method")
		if (search1 == "26"):
			print ("Si High Demo")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50787538/#editor")
			print ("Last modified: March 4th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean playing around with Scratch sprites, this week, Si")
		if (search1 == "27"):
			print ("Dumb ways to scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50993518/#editor")
			print ("Last modified: March 6th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete parody of dumb ways to die")
			print ("Comments")
			print ("The name doesn't seem innocent anynore. It was originally just word mixing of scratch and dumb ways to die. Now it seems like a perverted name. My innocence is dead")
			print ("Sean Myrick @ 12:43 PM on January 15th 2019")
		if (search1 == "28"):
			print ("Girl Game I")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52397548/#editor")
			print ("Last modified: March 14th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A game Sean made that seemed girlish to him (modern: silly)")
		if (search1 == "29"):
			print ("Escape the prison - scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52397774/#editor")
			print ("Last modified: March 14th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("A basic incomplete scratch parody of escape the prison")
		if (search1 == "30"):
			print ("War surival")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51983992/#editor")
			print ("Last modified: March 12th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An escape game where you survive a war [as usual, incomplete]")
		if (search1 == "31"):
			print ("rayco.com")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50972142/#editor")
			print ("Last modified: March 5th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A program based off of the old Dr. Ray series, one character of the abandoned TRM project")
		if (search1 == "32"):
			print ("Super Scratch Pong 2015")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50766984/#editor")
			print ("Last modified: March 4th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An attempted remaster of my original pong game, still abandoned")
		if (search1 == "33"):
			print ("Ancient Warfare I")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/52480364/#editor")
			print ("Last modified: March 14th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An abandoned ancient-themed battle game")
		if (search1 == "34"):
			print ("Job career test")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51983786/#editor")
			print ("Last modified: March 12th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An abandoned Job career test application")
		if (search1 == "35"):
			print ("Unlucky buttons")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50570780/#editor")
			print ("Last modified: March 3rd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Random buttons with random effects")
		if (search1 == "36"):
			print ("Nuclear cat roadmine")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53694682/#editor")
			print ("Last modified: March 21st 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Animation of scratch cat being nuked - I don't know why I made this")
		if (search1 == "37"):
			print ("Uncle Unicapricornicopria")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53968966/#editor")
			print ("Last modified: March 23rd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Bad animation made since Sean was bored, based off Uncle Grandpa")
		if (search1 == "38"):
			print ("Neon scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53969670/#editor")
			print ("Last modified: March 23rd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Scratch cat with a Neon effect")
		if (search1 == "39"):
			print ("Lol cat")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53973194/#editor")
			print ("Last modified: March 23rd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A derpy scratch cat")
		if (search1 == "40"):
			print ("Nauseator")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53999320/#editor")
			print ("Last modified: March 24th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Spinning spiral makes you dizzy")
		if (search1 == "41"):
			print ("Instruments")
			print ("By @Seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50969826/#editor")
			print ("Last modified: March 5th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Testing scratchs instrument sprites and sound samples")
		if (search1 == "42"):
			print ("The sounds of scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51992882/#editor")
			print ("Last modified: March 12th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A poor attempt to get all of scratch's sound effects into a soundboard")
		if (search1 == "43"):
			print ("None direction band")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/54392732/#editor")
			print ("Last modified: March 25th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another sound and sprite test (keep in mind, I wasn't fully aware of what one direction was when making this)")
		if (search1 == "44"):
			print ("Die hard")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/54585622/#editor")
			print ("Last modified: March 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("*NOT BASED ON THE MOVIE DIE HARD* I wasn't aware of that at the time. This is just another war survival game")
		if (search1 == "45"):
			print ("Bomb simulator")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/54625700/#editor")
			print ("Last modified: March 27th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Just bomb animations, not a very good bomb simulator")
		if (search1 == "46"):
			print ("Are you like sean quiz")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/54769944/#editor")
			print ("Last modified: March 27th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete quiz about Sean. ''Guess we will never know''")
		if (search1 == "47"):
			print ("Swift cat")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/54773742/#editor")
			print ("Last modified: March 27th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another random tweak to scratch cat. This time it's swift")
		if (search1 == "48"):
			print ("Most MLG scratch project ever")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/60834686/#editor")
			print ("Last modified: May 6th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Based off ''the most MLG game ever'' not a very good clone. Also MLG was really popular in my middle school at the time so this was bound to happen eventually")
		if (search1 == "49"):
			print ("Five nights at scratch 2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/60839230/#editor")
			print ("Last modified: May 6th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another FNAF game. This was during my FNAF phase")
		if (search1 == "50"):
			print ("Super scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63163944/#editor")
			print ("Last modified: May 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A platformer game to test platform programming. Very early start of my gravitational testing, not the best. Scratch themed")
		if (search1 == "51"):
			print ("Space story")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63166076/#editor")
			print ("Last modified: May 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A space story game, unfinished at the most, didn't go very far")
		if (search1 == "52"):
			print ("Plants vs. scratchies")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/61926272/#editor")
			print ("Last modified: May 12th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("This project was originally going to go on forever, but Sean got tired of it, and development stopped. This is a plants vs. zombies clone based off the Scratch theme")
		if (search1 == "53"):
			print ("Turkey cooking")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/61092764/#editor")
			print ("Last modified: May 8th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean needed more coping to his turkey-related issues and this was made. Poorly drawn, and hard to watch, this simulation shows a turkey being cooked")
		if (search1 == "54"):
			print ("Space quest")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/62324012/#editor")
			print ("Last modified: May 14th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")			
			print ("Another defend the planet clone, discontinued almost immediately due to boredom and lack of interest") 
		if (search1 == "55"):
			print ("Island survival")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63601986/#editor")
			print ("Last modified: May 21st 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A sandbox island survival game, this led to the basis of an upcoming sandbox series, this was just a simple test of how to work with inventory, physics, and exploring. It was discontinued before it could take off")
		if (search1 == "56"):
			print ("Untitled")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63809634/#editor")
			print ("Last modified: May 22nd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Abandoned from the start, Sean didn't know what he was doing and made a random scratch cat sprite and didn't know what to do with it")
		if (search1 == "57"):
			print ("Super scratch 2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63977388/#editor")
			print ("Last modified: May 24th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A discontinued clone of Super scratch, didn't make it that far as there was no plot. Right into the reject bin... as usual")
		if (search1 == "58"):
			print ("Survival maximum")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63977760/#editor")
			print ("Last modified: May 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A maximum security prison survival game, discontinued almost immediately. There was a lot of discontinuation at the start, as I kept learning more things that could be done with Scratch that should have been implemented at the start")
		if (search1 == "59"):
			print ("MLG Halloween 2015")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64115308/#editor")
			print ("Last modified: May 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A poorly made MLG game, discontinued almost immediately")
		if (search1 == "60"):
			print ("Most MLG scratch project ever 2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64118296/#editor")
			print ("Last modified: May 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A poorly made sequel to \"Most MLG scratch project ever\"Discontinued as usual")
		if (search1 == "61"):
			print ("A day at the beach")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64119628/#editor")
			print ("Last modified: May 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A quick animation about an adventure in a day at the beach")
		if (search1 == "62"):
			print ("War of control")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64258888/#editor")
			print ("Last modified: May 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An abandoned project about a war over protecting a button")
		if (search1 == "63"):
			print ("Game development studio")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64293664/#editor")
			print ("Last modified: May 27th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A simple sandbox game development studio, limited to a set of options, not much can really be done. Hey, at least it wasn't abandoned at the start")
		if (search1 == "64"):
			print ("The land of knowledge")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64625926/#editor")
			print ("Last modified: May 28th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A school full of knowledge, a discontinued educational game")
		if (search1 == "65"):
			print ("Island survival 2 - the lost realm")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64629492/#editor")
			print ("Last modified: May 28th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A sequel to \"Island survival\" That got discontinued almost immediately")
		if (search1 == "66"):
			print ("Game studio")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64476220/#editor")
			print ("Last modified: May 28th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A small game studio adventure, that got discontinued very fast")
		if (search1 == "67"):
			print ("Casino story copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64660304/#editor")
			print ("Last modified: May 28th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A casino development tycoon, run your own casino. This was actually a finished project, there just isn't much to do")
		if (search1 == "68"):
			print ("Farmpro premium")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64789880/#editor")
			print ("Last modified: May 29th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A basic farming tycoon with 1 plot of soil. Cookie clicker farm edition, discontinued")
		if (search1 == "69"):
			print ("Derp")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53569080/#editor")
			print ("Last modified: March 20th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An animation with level -6 humor. If you find everything funny, then this is for you!")
		if (search1 == "70"):
			print ("Untitled-2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64977410/#editor")
			print ("Last modified: May 31st 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Abandoned project, created by accident. Nothing was done with it except for paint a scratch cat green. There is nowhere else I wanted to go from here, unneccessary empty project :/")
		if (search1 == "71"):
			print ("Siege premium")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64988570/#editor")
			print ("Last modified: May 31st 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A vehicle driving game where you destroy stuff. A lot of these ideas really didn't have much to them, that is how I was able to put so many out in such short amounts of time. In the future of my scratch career, they get more complex, this is just API 1 of it")
		if (search1 == "72"):
			print ("Untitled-3")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64988790/#editor")
			print ("Last modified: May 31st 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Just scratch cat with a hat. Nothing spawned from this, just like untitled-2")
		if (search1 == "73"):
			print ("Fredbears pizza")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64991666/#editor")
			print ("Last modified: May 31st 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A FNAF world game before FNAF world even existed. It wasn't a very good creation. It was during my FNAF phase, but this project just doesn't have much to it")
		if (search1 == "74"):
			print ("Scratch explorer")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65360704/#editor")
			print ("Last modified: June 2nd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An explorer game with a working inventory. An early list test")
		if (search1 == "75"):
			print ("Castle story copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65363012/#editor")
			print ("Last modified: June 2nd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Not a copy, and not a complete game. As usual, it was abandoned from the start")
		if (search1 == "76"):
			print ("Scratch race")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65363086/#editor")
			print ("Last modified: June 2nd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A scratch racing game, movement functions test, not a complete program")
		if (search1 == "77"):
			print ("Turkey")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65572548/#editor")
			print ("Last modified: June 3rd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A picture of a raw turkey. Sean wasn't feeling good. However, this is one of the first projects with images uploaded from Sean's computer, and not just drawn in Scratch or assets from scratch")
		if (search1 == "78"):
			print ("Untitled-4")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65745306/#editor")
			print ("Last modified: June 4th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean was making a kitchen based game, but didn't like it that much. The image ruined it for him and the project was abandoned")
		if (search1 == "79"):
			print ("Untitled-5")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65757208/#editor")
			print ("Last modified: June 4th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Partly-hand drawn animation of a turkey getting butchered. It didn't go through, as Sean got disturbed and quit")
		if (search1 == "80"):
			print ("MLG")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65758064/#editor")
			print ("Last modified: June 4th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Accidental creation, just didn't delete. Accidentally renamed to MLG")
		if (search1 == "81"):
			print ("Turkey run")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65773788/#editor")
			print ("Last modified: June 5th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another turkey survival game, discontinued due to fear")
		if (search1 == "82"):
			print ("Untitled-6")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/66072396/#editor")
			print ("Last modified: June 7th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An accidental project, scratch cat was removed, and we are left with a 480x360 white background. Well, let's say an attempt was *almost* made")
		if (search1 == "83"):
			print ("Scratch party")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/66072934/#editor")
			print ("Last modified: June 7th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A basic party simulator with sprite animations from Scratch. Discontinued at the start")
		if (search1 == "84"):
			print ("Castle story")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65362536/#editor")
			print ("Last modified: June 2nd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("a continuation of Castle story with barely anything added. This was abandoned again")
		if (search1 == "86"):
			print ("Crossy scratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63809882/#editor")
			print ("Last modified: May 22nd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A crossy road clone that failed from the start. Discontinued")
		if (search1 == "87"):
			print ("Anamatronica")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65695854/#editor")
			print ("Last modified: June 4th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A sample FNAF demo game")
		if (search1 == "88"):
			print ("I-restaurant")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65566052/#editor")
			print ("Last modified: June 3rd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A restaurant story clone made to test 3D graphic skills. It didn't go very well :/")
		if (search1 == "89"):
			print ("Guide the missile")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64097586/#editor")
			print ("Last modified: May 25th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Guide a missile with a few planes. Not much to be done, it wasn't finished")
		if (search1 == "90"):
			print ("Band builder")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/66409250/#editor")
			print ("Last modified: June 9th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Build a band... or not, the project wasn't finished")
		if (search1 == "91"):
			print ("Super hack")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/66437142/#editor")
			print ("Last modified: June 10th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Incomplete animation of a homeless superhacker")
		if (search1 == "92"):
			print ("The scratch games")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/66715294/#editor")
			print ("Last modified: June 11th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete olympic game themed scratch adventure")
		if (search1 == "93"):
			print ("Five Nights At Scratch 3 INDEV 1.8.24.5 copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/66406380/#editor")
			print ("Last modified: June 9th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another Five Nights At Freddys fan game during my FNAF phase")
		if (search1 == "94"):
			print ("Alley maniac")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67008334/#editor")
			print ("Last modified: June 14th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete game of an insane person in an alley, trying to survive")
		if (search1 == "95"):
			print ("Who Wants To Be A Trillionaire adventure version")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67213482/#editor")
			print ("Last modified: June 15th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete clone of \"Who wants to be a millionaire\" Except it involves trillions")
		if (search1 == "96"):
			print ("Plants vs. bad")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67238838/#editor")
			print ("Last modified: June 16th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A plants vs. zombies game, but no zombies, just bad people")
		if (search1 == "97"):
			print ("Plants battles")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67830544/#editor")
			print ("Last modified: June 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Incomplete plants vs. zombies clone based in a forest")
		if (search1 == "98"):
			print ("Ultrascratch")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67907694/#editor")
			print ("Last modified: June 20th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An advanced sandbox builder with pre-loaded scratch-based assets. Incomplete")
		if (search1 == "99"):
			print ("Scratch comix copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67923890/#editor")
			print ("Last modified: June 21st 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A comic reader with incomplete comics")
		if (search1 == "100"):
			print ("Sweggy man adventures 1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67907334/#editor")
			print ("Last modified: June 20th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An incomplete platformer of a man with too much swag")
		if (search1 == "101"):
			print ("Brain tricker")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68274140/#editor")
			print ("Last modified: June 23rd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A game full of mind tricks")
		if (search1 == "102"):
			print ("Untitled-7")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68274444/#editor")
			print ("Last modified: June 23rd 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("An empty project made by accident")
		if (search1 == "103"):
			print ("MLG")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68410558/#editor")
			print ("Last modified: June 24th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Just an MLG image with a trickshot weapon")
		if (search1 == "104"):
			print ("Untitled-8")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68421432/#editor")
			print ("Last modified: June 25th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another empty project. The panoramic shot didn't work as I wanted it to")
		if (search1 == "105"):
			print ("Casino story 2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68421592/#editor")
			print ("Last modified: June 25th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A new and updated functional version of casino story")
		if (search1 == "106"):
			print ("Turkey stories")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67923906/#editor")
			print ("Last modified: June 21st 2015") 
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A turkey storygame based on the horrendous lives of thanksgiving turkeys")
		if (search1 == "107"):
			print ("MLG journeys")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68412372/#editor")
			print ("Last modified: June 24th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A discontinued MLG adventure game")
		if (search1 == "108"):
			print ("Plants vs. scratchies alpha 1.0")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68538248/#editor")
			print ("Last modified: June 25th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A new version of plants vs. scratchies")
		if (search1 == "109"):
			print ("Immortal combat")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68543238/#editor")
			print ("Last modified: June 25th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another failed mortal combat clone with no idea what immortal combat was like")
		if (search1 == "110"):
			print ("Scrolls seanwallawalla edition")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68637898/#editor")
			print ("Last modified: June 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Explorer game that was discontinued")
		if (search1 == "111"):
			print ("Street builder")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68652656/#editor")
			print ("Last modified: June 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A street building tycoon where you get to build a neighborhood")
		if (search1 == "112"):
			print ("Night mode app")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68823788/#editor")
			print ("Last modified: June 29th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A night mode app - it doesn't really mean anything")
		if (search1 == "113"):
			print ("The seanwallawalla app")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68923668/#editor")
			print ("Last modified: June 29th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Discontinued app that failed at the start, as there was no plot")
		if (search1 == "114"):
			print ("Seans torture")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68939422/#editor")
			print ("Last modified: June 30th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean wasn't feeling good again and he made this. Experience a turkey being tortured by the oven")
		if (search1 == "115"):
			print ("Untitled-9")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69167622/#editor")
			print ("Last modified: July 1st 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Immediately dropped project as nothing was done")
		if (search1 == "116"):
			print ("Gobo army")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69491176/#editor")
			print ("Last modified: July 5th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Build up an army of Gobo's with gobo army")
		if (search1 == "117"):
			print ("Scratch journey")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69496224/#editor")
			print ("Last modified: July 5th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A little scratch adventure game - I have made so many of these")
		if (search1 == "118"):
			print ("Turkey defense 2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69595026/#editor")
			print ("Last modified: July 6th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("The most resource hungry scratch project Sean ever made. It got so out of hand his own computer couldn't handle it. Sean thought he went over the limit. However on January 16th 2019, Sean got to get the project again this time with 8 GB RAM. It is only 11 MB but it requires so much")
		if (search1 == "119"):
			print ("Memes memes of anenememes")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70224720/#editor")
			print ("Last modified: July 13th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Basic meme soundboard")
		if (search1 == "120"):
			print ("The Sean walla walla app")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70562708/#editor")
			print ("Last modified: July 18th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another attempt at the Sean Walla Walla app. Functional but doesn't do much")
		if (search1 == "121"):
			print ("World of survival")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70563696/#editor")
			print ("Last modified: July 16th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A basic survival game with a small 2D map")
		if (search1 == "122"):
			print ("Techlaration test selector")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70673738/#editor")
			print ("Last modified: July 17th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("The abandoned techlaration company names test selector for employee training. Discontinued")
		if (search1 == "123"):
			print ("Stick figures")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70832960/#editor")
			print ("Last modified: July 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A basic stick figure animation")
		if (search1 == "124"):
			print ("Zombie siege")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70870498/#editor")
			print ("Last modified: July 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A zombie surival demo game. Discontinued due to low interest")
		if (search1 == "125"):
			print ("U")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70881448/#editor")
			print ("Last modified: July 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Was going to be a survival game, but it was discontinued on the first scene")
		if (search1 == "126"):
			print ("Store story")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70881954/#editor")
			print ("Last modified: July 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A market tycoon game that was discontinued as it had no plot and Sean wasn't interested enough in it")
		if (search1 == "127"):
			print ("My scratch cat")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71513474/#editor")
			print ("Last modified: July 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Based off talking tom, a virtual pet you can interact with. Not much to do")
		if (search1 == "128"):
			print ("Rasple Operating System version 1.1.0 copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71802438/#editor")
			print ("Last modified: July 29th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Discontinued rasple operating systen (keep in mind, I had little knowledge on technology back then and I thought I could make this into an operating system) ")
		if (search1 == "129"):
			print ("Band music card version 1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70831690/#editor")
			print ("Last modified: July 19th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean's first publically shared project. It is a band music card designed for an upcoming birthday (July 31st) it is a complete program")
		if (search1 == "130"):
			print ("Raspberry fever beta 1.2.6")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69036218/#editor")
			print ("Last modified: June 30th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Sean's second publically shared project. It is a collection game where you collect raspberries")
		if (search1 == "131"):
			print ("Turkey hop")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68939666/#editor")
			print ("Last modified: June 30th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another turkey survival game, Sean wasn't doing well in this time period")
		if (search1 == "132"):
			print ("Get rekt anna")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64260372/#editor")
			print ("Last modified: May 26th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A weird animation of the scratch sprite anna getting ''completely'' destroyed")
		if (search1 == "133"):
			print ("Insanity pong")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/62945230/#editor")
			print ("Last modified: May 18th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Another attempt at pong, this one had potentional, but it was abandoned")
		if (search1 == "134"):
			print ("What I learned in scratch 2015")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/66067150/#editor")
			print ("Last modified: June 7th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("This wasn't a full documentation, this was poorly built. I learned more than this in Scratch this year, and it wasn't even the end of the year yet. Horribly timed")
		if (search1 == "135"):
			print ("Christmas 2015")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64104654/#editor")
			print ("Last modified: May 25th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Christmas in may? Who cares, lets test out the sprites - an early christmas animation to test out winter-related sprites")
		if (search1 == "136"):
			print ("Turkey dinner")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63205160/#editor")
			print ("Last modified: May 20th 2015")
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Turkey getting cooked - Just the usual")
		if (search1 == "137"):
			print ("Seizure pro")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53520980/#editor")
			print ("Last modified: March 21st 2015")
			print ("Sharing status: Shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("A seizure simulator, made for fun")
		if (search1 == "138"):
			print ("Funny scratch moments part 2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53599862/#editor")
			print ("Last modified: March 3rd 2015")
			print ("Sharing status: Shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("Based off:
			print ("
		if (search1 == "139"):
			print ("Funny scratch moments part 1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53569398/#editor"
			print ("Last modified: March 20th 2015")
			print ("Sharing status: Shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "140"):
			print ("extremely awkward splash plane attack")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50570890/#editor")
			print ("Last modified: March 3rd 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "141"):
			print ("All about me")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/53170138/editor")
			print ("Last modified: March 18th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "142"):
			print ("Rasple Operating System version 1.1.1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71620020/#editor")
			print ("Last modified: July 27th 2015") 
			print ("Sharing status: never shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "143"):
			print ("Five nights at scratch 3 night 4")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71816716/editor")
			print ("Last modified: July 29th 2015")
			print ("Sharing status: Never shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "144"):
			print ("Jurassic Universe")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69502904/editor")
			print ("Last modified: July 5th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "145"):
			print ("Turkey Oven 1.4.2"(
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/65774730/#editor")
			print ("Last modified: June 5th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "146"):
			print ("Scratch TV Demp")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/68646060/#editor")
			print ("Last modified: June 26th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "147"):
			print ("Knight Journey demo")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69143328/#editor")
			print ("Last modified: July 1st 2015")
			print (" 
			print ("Sharing status: shared")
			print ("View count: " + str(projectA147ViewCount))
			print ("Like count:  " + str(projectA1471LikeCount))
			print ("Favorite count: " + str(projectA147FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 8+")
			print ("Personal rating: 4.1/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 128 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "148"):
			print ("Turkey simulator 1.5.4")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/63420148/#editor")
			print ("Last modified: May 21st 2015")
			print ("Sharing status: shared") 
			print ("View count: " + str(projectA148ViewCount))
			print ("Like count:  " + str(projectA148LikeCount))
			print ("Favorite count: " + str(projectA148FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 10+")
			print ("Personal rating: 4.2/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement:  128 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "149"):
			print ("Turkey defense")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69446072/#editor")
			print ("Last modified: July 5th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA149ViewCount))
			print ("Like count:  " + str(projectA149LikeCount))
			print ("Favorite count: " + str(projectA149FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 10+")
			print ("Personal rating: 3.9/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 256 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "150"):
			print ("Scratchtastic demo")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/69432910/#editor")
			print ("Last modified: July 4th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA150ViewCount))
			print ("Like count:  " + str(projectA150LikeCount))
			print ("Favorite count: " + str(projectA150FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.1/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "151"):
			print ("Scrub wrecker")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/64604042/#editor")
			print ("Last modified: May 28th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA151ViewCount))
			print ("Like count:  " + str(projectA151LikeCount))
			print ("Favorite count: " + str(projectA151FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 10+")
			print ("Personal rating: 3.1/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "152"):
			print ("Turkey simulator")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51372092/#editor")
			print ("Last modified: March 9th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA152ViewCount))
			print ("Like count:  " + str(projectA152LikeCount))
			print ("Favorite count: " + str(projectA152FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 10+")
			print ("Personal rating: 3.6/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 256 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "153"):
			print ("Sea tales")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/50987626/#editor")
			print ("Last modified: March 6th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA153ViewCount))
			print ("Like count:  " + str(projectA153LikeCount))
			print ("Favorite count: " + str(projectA153FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.6/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "154"):
			print ("Dumb ways to die - Turkey edition")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51771408/#editor")
			print ("Last modified: March 10th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA154ViewCount))
			print ("Like count:  " + str(projectA154LikeCount))
			print ("Favorite count: " + str(projectA154FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 12+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 128 megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "155"):
			print ("Turkey nightmare II")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51987068/#editor")
			print ("Last modified: March 12th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA155ViewCount))
			print ("Like count:  " + str(projectA155LikeCount))
			print ("Favorite count: " + str(projectA155FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 10+")
			print ("Personal rating: 3.6/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 96 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "156"):
			print ("Turkey nightmare III")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51988968/#editor")
			print ("Last modified: March 12th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA156ViewCount))
			print ("Like count:  " + str(projectA156LikeCount))
			print ("Favorite count: " + str(projectA156FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 10+")
			print ("Personal rating: 3.1/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 96 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "157"):
			print ("Turkey Nightmare I")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/51976980/#editor")
			print ("Last modified: March 11th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA157ViewCount))
			print ("Like count:  " + str(projectA157LikeCount))
			print ("Favorite count: " + str(projectA157FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 10+")
			print ("Personal rating: 3.1/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 128 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "158"):
			print ("The scratcher")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/67082552/#editor")
			print ("Last modified: shared")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA158ViewCount))
			print ("Like count:  " + str(projectA158LikeCount))
			print ("Favorite count: " + str(projectA158FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.3/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "159"):
			print ("Hospital quest demo")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70749198/#editor")
			print ("Last modified: July 17th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA159ViewCount))
			print ("Like count:  " + str(projectA159LikeCount))
			print ("Favorite count: " + str(projectA159FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 8+")
			print ("Personal rating: 4.0/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 150 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "160"):
			print ("Untitled-10")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71901894/#editor")
			print ("Last modified: July 30th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA160ViewCount))
			print ("Like count:  " + str(projectA160LikeCount))
			print ("Favorite count: " + str(projectA160FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+") 
			print ("Personal rating: 3.5/5.0")
			print ("Original tags:  
			print ("Language: English")
			print ("RAM requirement: 64 megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "161"):
			print ("TRM Galaxy of code version 1 copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71906692/#editor")
			print ("Last modified: July 30th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA161ViewCount))
			print ("Like count:  " + str(projectA161LikeCount))
			print ("Favorite count: " + str(projectA161FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 3.3/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "162"):
			print ("Mass destruction")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71807588/#editor")
			print ("Last modified: July 29th 2015")
			print ("Sharing status:  not shared")
			print ("View count: " + str(projectA162ViewCount))
			print ("Like count:  " + str(projectA162LikeCount))
			print ("Favorite count: " + str(projectA162FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 9+")
			print ("Personal rating: 3.7/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 96 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "163"):
			print ("Untitled-11")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71917718/#editor")
			print ("Last modified: July 31st 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA163ViewCount))
			print ("Like count:  " + str(projectA163LikeCount))
			print ("Favorite count: " + str(projectA163FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.1/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "164"):
			print ("TRM Galaxy of code version 1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71900052/#editor")
			print ("Last modified: July 30th 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA164ViewCount))
			print ("Like count:  " + str(projectA164LikeCount))
			print ("Favorite count: " + str(projectA164FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 3.5/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "165"):
			print ("TRM quiz")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71988982/#editor")
			print ("Last modified: July 31st 2015") 
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA165ViewCount))
			print ("Like count:  " + str(projectA165LikeCount))
			print ("Favorite count: " + str(projectA165FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 3.5/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 96 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "166"):
			print ("Five Nights At Freddys Reborn demo 1.1 -2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71991864/#editor")
			print ("Last modified: July 31st 2015") 
			print ("Sharing status: shared")
			print ("View count: " + str(projectA166ViewCount))
			print ("Like count:  " + str(projectA166LikeCount))
			print ("Favorite count: " + str(projectA166FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 12+")
			print ("Personal rating: 4.1/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 300 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "167"):
			print ("Five Nights At Freddys Reborn demo 1.0")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70213400/#editor")
			print ("Last modified: July 12th 2015")
			print ("Sharing status:  shared")
			print ("View count: " + str(projectA167ViewCount))
			print ("Like count:  " + str(projectA1671LikeCount))
			print ("Favorite count: " + str(projectA167FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 12+")
			print ("Personal rating: 3.6/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 300 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "168"):
			print ("Five Nights At Freddys Reborn demo 1.1.1-2")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71994360/#editor")
			print ("Last modified: August 1st 2015")
			print ("Sharing status: shared")
			print ("View count: " + str(projectA168ViewCount))
			print ("Like count:  " + str(projectA168LikeCount))
			print ("Favorite count: " + str(projectA168FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 12+")
			print ("Personal rating: 3.6/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 336 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "169"):
			print ("Five Nights At Freddys Memes 1.1 copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72105740/#editor")
			print ("Last modified: August 2nd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA169ViewCount))
			print ("Like count:  " + str(projectA169LikeCount))
			print ("Favorite count: " + str(projectA169FavCount))
			print ("Takedown status: Taken down due to community guidelines violations (which I wasn't aware of at the time)")
			print ("Age rating: 17+")
			print ("Personal rating: 2.7/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "170"):
			print ("Five Nights At Freddys Memes 1.1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72100498/#editor")
			print ("Last modified: August 2nd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA170ViewCount))
			print ("Like count:  " + str(projectA170LikeCount))
			print ("Favorite count: " + str(projectA170FavCount))
			print ("Takedown status: Taken down due to community guidelines violations (which I wasn't aware of at the time)")
			print ("Age rating: 17+")
			print ("Personal rating: 2.7/5.0")
			print ("Original tags: 
			print ("Language: Englosh")
			print ("RAM requirement:  64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "171"):
			print ("Five Nights At Freddys Reborn demo 1.1.1 copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72169330/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA171ViewCount))
			print ("Like count:  " + str(projectA171LikeCount))
			print ("Favorite count: " + str(projectA171FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 12+")
			print ("Personal rating: 3.5/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 300 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "172"):
			print ("Five Nights At Freddys Reborn demo 1.1.1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/71976984/#editor")
			print ("Last modified: July 31st 2015")
			print ("Sharing status:  shared")
			print ("View count: " + str(projectA172ViewCount))
			print ("Like count:  " + str(projectA172LikeCount))
			print ("Favorite count: " + str(projectA172FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 12+")
			print ("Personal rating: 4.0/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 300 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "173"):
			print ("Five nighrs at freddys 3")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72042350/#editor")
			print ("Last modified: August 1st 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA173ViewCount))
			print ("Like count:  " + str(projectA173LikeCount))
			print ("Favorite count: " + str(projectA173FavCount))
			print ("Takedown status: taken down due to violation of community guidelines (unknown at the time)")
			print ("Age rating: 13+")
			print ("Personal rating: 2.1/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 500 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "174"):
			print ("Scratch run")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72180336/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA174ViewCount))
			print ("Like count:  " + str(projectA174LikeCount))
			print ("Favorite count: " + str(projectA174FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 3.5/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "175"):
			print ("Clash of clans memes 1.0 copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72183880/#editor") 
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared") 
			print ("View count: " + str(projectA175ViewCount))
			print ("Like count:  " + str(projectA175LikeCount))
			print ("Favorite count: " + str(projectA175FavCount))
			print ("Takedown status: taken down due to violations of community guidelines (unknown at the time)")
			print ("Age rating: 17+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "176"):
			print ("Clash of clans memes 1.0")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72181236/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA176ViewCount))
			print ("Like count:  " + str(projectA176LikeCount))
			print ("Favorite count: " + str(projectA176FavCount))
			print ("Takedown status: taken down due to violations of community guidelines (unknown at the time)")
			print ("Age rating: 17+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "177"):
			print ("Daily memes 1.0 copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72188510/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA177ViewCount))
			print ("Like count:  " + str(projectA177LikeCount))
			print ("Favorite count: " + str(projectA177FavCount))
			print ("Takedown status: taken down due to violations of community guidelines (unknown at the time)")
			print ("Age rating: 17+")
			print ("Personal rating: 2.9/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "178"):
			print ("Grand theft scratch 1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72180842/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA178ViewCount))
			print ("Like count:  " + str(projectA178LikeCount))
			print ("Favorite count: " + str(projectA178FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "179"):
			print ("Family guy memes 1.0 copy")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72191180/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA179ViewCount))
			print ("Like count:  " + str(projectA179LikeCount))
			print ("Favorite count: " + str(projectA179FavCount))
			print ("Takedown status: taken down due to violation of community guidelines (unknown at the time)")
			print ("Age rating: 17+")
			print ("Personal rating: 2.9/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "180"):
			print ("Family guy memes 1.1")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72188576/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA180ViewCount))
			print ("Like count:  " + str(projectA180LikeCount))
			print ("Favorite count: " + str(projectA180FavCount))
			print ("Takedown status: taken down due to violation of community guidelines (unknown at the time)")
			print ("Age rating: 17+")
			print ("Personal rating: 2.8/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "181"):
			print ("Five Nights At Freddys Memes 1.0 Redo")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72048736/#editor")
			print ("Last modified: August 1st 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA181ViewCount))
			print ("Like count:  " + str(projectA181LikeCount))
			print ("Favorite count: " + str(projectA181FavCount))
			print ("Takedown status: taken down due to community guidelines violation (attempted fix failed)")
			print ("Age rating: 17+")
			print ("Personal rating: 2.9/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "182"):
			print ("Daily memes 1.0")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72163054/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA182ViewCount))
			print ("Like count:  " + str(projectA182LikeCount))
			print ("Favorite count: " + str(projectA182FavCount))
			print ("Takedown status: taken down due to violation of community guidelines")
			print ("Age rating: 17+")
			print ("Personal rating: 2.9/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 32 megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "183"):
			print ("Formula 75 racing")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/70648492/#editor")
			print ("Last modified: July 16th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA183ViewCount))
			print ("Like count:  " + str(projectA183LikeCount))
			print ("Favorite count: " + str(projectA183FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.6/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "184"):
			print ("Scratch help guide")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72380460/#editor")
			print ("Last modified: August 5th 2016")
			print ("Sharing status: not shared") 
			print ("View count: " + str(projectA184ViewCount))
			print ("Like count:  " + str(projectA184LikeCount))
			print ("Favorite count: " + str(projectA184FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 3.2/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "185"):
			print ("Bug life")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72196988/#editor")
			print ("Last modified: August 3rd 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA185ViewCount))
			print ("Like count:  " + str(projectA185LikeCount))
			print ("Favorite count: " + str(projectA185FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.9/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "186"):
			print ("Scratch go!")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/72459050/#editor")
			print ("Last modified: August 6th 2015")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectA186ViewCount))
			print ("Like count:  " + str(projectA186LikeCount))
			print ("Favorite count: " + str(projectA186FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 6+")
			print ("Personal rating: 3.5/5.0")
			print ("Original tags: 
			print ("Language: English")
			print ("RAM requirement: 64 megabytes")
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("File size:
			print ("Original file type: SB2")
			print ("Current file type: SB3")
			print ("
		if (search1 == "about" or search1 == "About" or search1 == "ABOUT" or search1 == "aBOUT"):
			print ("About")
			print ("This is a python based directory containing info for all scratch projects hosted on Sean's main scratch account")
		if (search1 == "pattern" or search1 == "Pattern" or search1 == "PATTERN" or search1 == "pATTERN"):
			print ("last project pattern")
			print ("_________________________________")
			print ("| #    | date      | file | day |")
			print ("| 0036 | 1/14/2019 | SB3  | 01  |")
			print ("| 0086 | 1/15/2019 | SB3  | 02  |")
			print ("| 0136 | 1/16/2019 | SB3  | 03  |")
			print ("| 0186 | 1/17/2019 | SB3  | 04  |")
			print ("| 0236 | 1/18/2019 | SB3  | 05  |")
			print ("| 0286 | 1/19/2019 | SB3  | 06  |")
			print ("| 0336 | 1/20/2019 | SB3  | 07  |")
			print ("| 0386 | 1/21/2019 | SB3  | 08  |")
			print ("| 0436 | 1/22/2019 | SB3  | 09  |")
			print ("| 0486 | 1/23/2019 | SB3  | 10  |")
			print ("| 0536 | 1/24/2019 | SB3  | 11  |")
			print ("| 0586 | 1/25/2019 | SB3  | 12  |")
			print ("| 0636 | 1/26/2019 | SB3  | 13  |")
			print ("| 0686 | 1/27/2019 | SB3  | 14  |")
			print ("| 0736 | 1/28/2019 | SB3  | 15  |")
			print ("| 0786 | 1/29/2019 | SB3  | 16  |")
			print ("| 0836 | 1/30/2019 | SB3  | 17  |")
			print ("| 0886 | 1/31/2019 | SB3  | 18  |")
			print ("| 0936 | 2/01/2019 | SB3  | 19  |")
			print ("| 0986 | 2/02/2019 | SB3  | 20  |")
			print ("| 1036 | 2/03/2019 | SB3  | 21  |")
			print ("| 1086 | 2/04/2019 | SB3  | 22  |")
			print ("| 1136 | 2/05/2019 | SB3  | 23  |")
			print ("| 1186 | 2/06/2019 | SB3  | 24  |")
			print ("| 1236 | 2/07/2019 | SB3  | 25  |")
			print ("| 1286 | 2/08/2019 | SB3  | 26  |")
			print ("| 1336 | 2/09/2019 | SB3  | 27  |")
			print ("=================================")
			noMore = input("Press [ENTER] key to continue")
		noMore = input("Those are all of Sean's scratch projects\nPress [ENTER] key to exit")
if (userSel == 2):
	loopWallaWalla = int(1)
	while (loopWallaWalla == 1):
		print ("My scratch projects")
		print ("From scratch.mit.edu")
		print ("7 items")
		print ("\n")
		print ("________________________________________________________")
		print ("| 1 | Scratch Tutorial Episode 1_ how to make a button |")
		print ("| 2 | Scratch tutorial ep2 how to make a working clock |")
		print ("| 3 | video thumbnail for 100 subscriber special       |")
		print ("| 4 | over 10k liked twitter tweets screenshot         |")
		print ("| 5 | I got world of the day in growtopia 7_19_2017    |")
		print ("| 6 | bill gates is no longer the worlds richest man   |")
		print ("| 7 | My New Youtube Roadblock                         |")
		print ("========================================================")
		print (" ")
		# project B1 statistics 
		projectB1ViewCount = int(1)
		projectB1LikeCount = int(0)
		projectB1FavCount = int(0)
		# project B2 statistics
		projectB2ViewCount = int(1)
		projectB2LikeCount = int(0)
		projectB2FavCount = int(0)
		# project B3 statistics
		projectB3ViewCount = int(1)
		projectB3LikeCount = int(1)
		projectB3FavCount = int(1)
		# project B4 statistics
		projectB4ViewCount = int(2)
		projectB4LikeCount = int(1)
		projectB4FavCount = int(1)
		# project B5 statistics
		projectB5ViewCount = int(5)
		projectB5LikeCount = int(1)
		projectB5FavCount = int(1)
		# project B6 statistics
		projectB6ViewCount = int(3)
		projectB6LikeCount = int(1)
		projectB6FavCount = int(1)
		# project B7 statistics
		projectB7ViewCount = int(3)
		projectB7LikeCount = int(1)
		projectB7FavCount = int(1)
		search1 = str(input("Search a project before you leave? type a number 1 through 1336 or type 'about' \nOther commands:\t\tPattern"))
		if (search1 == "1"):
			print ("Scratch Tutorial Episode 1_ how to make a button")
			print ("By @Seanwallawalla")
			print ("Project URL: https://scratch.mit.edu/projects/107712340/#editor")
			print ("Last modified: April 30th 2016")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status: never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 4.1/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 64 Megabytes")
			print ("Inspired by: YouTube tutorial videos")
			print ("Genre: Programming")
			print ("Category: Tutorials")
			print ("Finish status: Finished")
			print ("Based off: how to make a working interactive button in scratch")
			print ("This is a simple tutorial I made on how to make an interactive button in Scratch 2 (also works with scratch 3) that lights up when you touch it")
			noMore = input("Press [ENTER] key to continue")
		if (search1 == "2"):
			print ("Scratch tutorial ep2 how to make a working clock")
			print ("By @seanwallwalla")
			print ("Project URL: https://scratch.mit.edu/projects/107926964/#editor")
			print ("Last modified: May 2nd 2016")
			print ("Sharing status: not shared")
			print ("View count: " + str(projectB2ViewCount))
			print ("Like count:  " + str(projectB2LikeCount))
			print ("Favorite count: " + str(projectB2FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating: 5+")
			print ("Personal rating: 2.4/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by: YouTube tutorial videos")
			print ("Genre: Programming")
			print ("Category: Tutorials")
			print ("Finish status: Finished")
			print ("Based off: how to make a working clock in scratch")
			print ("This is a simple tutorial I made on how to make a working clock in Scratch 2 (also works with Scratch 3) that runs on real time")
			noMore = input("Press [ENTER] key to continue")
		if (search1 == "3"):
			print ("video thumbnail for 100 subscriber special")
			print ("By @seanspokane2015")
			print ("Project URL: https://scratch.mit.edu/projects/167183183/#editor")
			print ("Last modified: June 24th 2017")
			print ("Sharing status: Shared")
			print ("View count: " + str(projectB3ViewCount))
			print ("Like count:  " + str(projectB3LikeCount))
			print ("Favorite count: " + str(projectB3FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating: 7+")
			print ("Personal rating: 3.6/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by: reaching 100 subscribers on YouTube")
			print ("Genre: Art gallery")
			print ("Category: Graphic design thumbnails") # MS-PAINT counts, come on!
			print ("Finish status: Finished")
			print ("Based off: A thumbnail I made for a 100 subscriber special")
			print ("This project is literally just a thumbnail. It was made for celebrating 100 subscribers on my YouTube channel Sean Walla Walla")
			noMore = input("Press [ENTER] key to continue")
		if (search1 == "4"):
			print ("over 10k liked twitter tweets screenshot")
			print ("By @seanwallawalla")
			print ("Project URL: https://scratch.mit.edu/projects/168325483/#editor")
			print ("Last modified: July 7th 2017")
			print ("Sharing status: Shared")
			print ("View count: " + str(projectB4ViewCount))
			print ("Like count:  " + str(projectB4LikeCount))
			print ("Favorite count: " + str(projectB4FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating: 7+")
			print ("Personal rating: 3.9/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by: Liking 10000 tweets on twitter") 
			print ("Genre: Art gallery")
			print ("Category: screenshots and screenclips")
			print ("Finish status: Finished")
			print ("Based off: a screenshot of the liked tweets count of 10000")
			print ("This project is just a screenshot of me liking 10000 tweets on twitter. It took a while, but I did it!")
			noMore = input("Press [ENTER] key to continue")
		if (search1 == "5"):
			print ("I got world of the day in growtopia 7_19_2017")
			print ("By @seanwallawalla")
			print ("Project URL: https://scratch.mit.edu/projects/169265649/#editor")
			print ("Last modified: July 19th 2017")
			print ("Sharing status: Shared")
			print ("View count: " + str(projectB5ViewCount))
			print ("Like count:  " + str(projectB5LikeCount))
			print ("Favorite count: " + str(projectB5FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating: 7+")
			print ("Personal rating: 4.1/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by: Getting world of the day in Growtopia")
			print ("Genre: Gaming")
			print ("Category: Gaming screenshots")
			print ("Finish status: Finished")
			print ("Based off: Getting the world of the day achievement in Growtopia")
			print ("This project is just a screenshot of my growtopia achievement. It came out of nowhere and I still don't know why I got it")
			noMore = input("Press [ENTER] key to continue")
		if (search1 == "6"):
			print ("bill gates is no longer the worlds richest man ")
			print ("By @seanwallawalla")
			print ("Project URL: https://scratch.mit.edu/projects/169945112/#editor")
			print ("Last modified: July 28th 2017")
			print ("Sharing status: Shared")
			print ("View count: " + str(projectB6ViewCount))
			print ("Like count:  " + str(projectB6LikeCount))
			print ("Favorite count: " + str(projectB6FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating: 7+")
			print ("Personal rating: 3.8/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by: Bill gates dropping in the leaderboard of billionaires")
			print ("Genre: News and current events")
			print ("Category: News stories")
			print ("Finish status: Finished")
			print ("Based off: Bill gates dropping his leaderboard rank")
			print ("This project was made in a hurry when Sean found out that Bill gates was replaced by Jeff Bezos as richest man in the world")
			noMore = input("Press [ENTER] key to continue")
		if (search1 == "7"):
			print ("My New Youtube Roadblock")
			print ("By @seanwallawalla")
			print ("Project URL: https://scratch.mit.edu/projects/169945458/#editor")
			print ("Last modified: July 27th 2017")
			print ("Sharing status: Shared")
			print ("View count: " + str(projectB7ViewCount))
			print ("Like count:  " + str(projectB7LikeCount))
			print ("Favorite count: " + str(projectB7FavCount))
			print ("Takedown status: Never taken down")
			print ("Age rating: 7+")
			print ("Personal rating: 2.9/5.0")
			print ("Original tags: <none>")
			print ("Language: English")
			print ("RAM requirement: 32 Megabytes")
			print ("Inspired by: YouTube messing up again")
			print ("Genre: Life events")
			print ("Category: YouTube news")
			print ("Finish status: Finished")
			print ("Based off: Losing a big YouTube feature")
			print ("This was the last project made on this account and it wasn't that impressive either. I ran into the roadblock of YouTube removing the slideshow creator")
			noMore = input("Press [ENTER] key to continue")
		if (search1 == "about" or search1 == "About" or search1 == "aBOUT" or search1 == "ABOUT"):
			print ("About this scratch account")
			print ("\nOriginal Bio:\n\n")
			print ("ABOUT ME")
			print ("youtube channel: sean walla walla")
			print ("joined youtube on may 14th 2015") 
			print ("daily videos")
			print ("i thought i joined in april but i actually joined in may")
			print (" ")
			print ("WHAT I'M WORKING ON")
			print ("my original account")
			print ("seanspokane2015")
			print ("this is just my youtube account. subscribe to my channel which is the exact same as my username for this account")
			print (" ")
			print ("This account wasn't as used as my main account and was mainly used for YouTube videos, and even though my channel was extremely active at the time, most of the content just went over to @Seanspokane2015")
			print ("This account never saw the light of day in its prime, and was abandoned, as @seanspokane2015 was doing it better")
			print ("====================================================================================================================================================================================================================")
			noMore = input("Press [ENTER] key to continue")
		
# Version 1.25
# January 16th 2019 build
'''
if (search1 == "86"):
	print ("
	print ("By @seanspokane2015")
	print ("Project URL:
	print ("Last modified:
	print (" 
	print ("Sharing status: 
	print ("View count: " + str(projectB1ViewCount))
	print ("Like count:  " + str(projectB1LikeCount))
	print ("Favorite count: " + str(projectB1FavCount))
	print ("Takedown status:
	print ("Age rating:
	print ("Personal rating:
	print ("Original tags: 
	print ("Language:
	print ("RAM requirement: 
	print ("Inspired by:
	print ("Genre:
	print ("Category:
	print ("Finish status:
	print ("Based off:
	print ("
			
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("
		if (search1 == "137"):
			print ("
			print ("By @seanspokane2015")
			print ("Project URL:
			print ("Last modified:
			print (" 
			print ("Sharing status: 
			print ("View count: " + str(projectB1ViewCount))
			print ("Like count:  " + str(projectB1LikeCount))
			print ("Favorite count: " + str(projectB1FavCount))
			print ("Takedown status:
			print ("Age rating:
			print ("Personal rating:
			print ("Original tags: 
			print ("Language:
			print ("RAM requirement: 
			print ("Inspired by:
			print ("Genre:
			print ("Category:
			print ("Finish status:
			print ("Based off:
			print ("
'''
# features to add by version 2.0
'''
01(*) loop all
02(*) choose between @seanspokane2015 and @seanwallawalla
03(*) original project description 
04(*) bio for both users 
05(*) original bio for both users 
06(*) development log 
07(*) sorting projects by # A-Z Z-A Date modified, size, ID, 
08(*) sorted project folder for categories 
09(*) grouos of projects 
10(*) link sorting 
11(*) search with 01, 001, 0001
12(*) 0 defaults to 1 and anything above 1336 defaults to 1
13(*) year categories (2015, 2016, 2017)
14(*) original file formats (SB2 for everything)
15(*) project file size (bytes, Kilobytes, Megabytes)
16(*) shared or not shared 
17(*) follower list 
18(*) following list + backstory
19(*) story about zombieliukang
20(*) story about revengeseal
21(*) story about my experience with griffpatch (include gruffpatch parody)
22(*) stories section 
23(*) original platform (Google chrome, Windows 7, Windows 8, Windows 10)
24(*) why I quit uploading to scratch 
25(*) block count 
26(*) sprite count (luckily it is included into the project)
27(*) sort by remixes
28(*) comments on profile 
29(*) profile 
30(*) studios and associated studios 
31(*) taken down and not taken down 
32(*) made in USA Walla Walla 
33(*) View integer - per
34(*) view integer - per profile 
35(*) view integer - all time
36(*) like integer - per 
37(*) like integer - per profile 
38(*) like integer - all time 
39(*) favorite integer - per 
40(*) favorite integer - per profile 
41(*) favorite integer - all time
42(*) personal rating 
43(*) project count - per category
44(*) project count - per profile
45(*) project count - all time 
46(*) language 
47(*) category 
48(*) sort by month 
49(*) sort by year 
50(*) age rating 
51(*) based off/OC
52(*) finished (Y/N)
53(*) RAM requirement 
54(*) genre 
55(*) inspired by 
56(*) original tags
'''